program EgmfCheck
  use constantes
  implicit none

  real(prec) :: gamma0,gamma_expected,gamma_p,gamma_e
  real(prec) :: x0,y0,zpos0,up,vp,wp,ue,ve,we
  real(prec) :: xp,yp,zp,xe,ye,ze,normp,norme
  real(prec) :: zini,zfinal

  call gauleg(ngp,xabsc,weig)
  UseEGMF=.true.
  UseSynchrotron=.false.
  UseAccComptonForEGMF=.false.
  B_mode=0
  EGMF_phi_max=5.D-2

  zini=0.1_prec
  zfinal=0.05_prec
  gamma0=10._prec
  x0=0._prec
  y0=0._prec
  zpos0=0._prec
  up=0.3_prec
  vp=0.4_prec
  wp=sqrt(max(0._prec,1._prec-up*up-vp*vp))
  EGMF_B0_G=(/0._prec,0._prec,0._prec/)

  call trajectoireLepton(zini,zfinal,gamma0,x0,y0,zpos0,up,vp,wp,1)
  gamma_expected=sqrt(1._prec+(10._prec**2-1._prec)*((1._prec+zfinal)/(1._prec+zini))**2)
  if (abs(gamma0-gamma_expected).gt.1.D-10) then
     write(*,*), 'B=0 gamma mismatch', gamma0, gamma_expected
     stop 1
  end if
  if (abs(up-0.3_prec).gt.1.D-12.or.abs(vp-0.4_prec).gt.1.D-12) then
     write(*,*), 'B=0 direction changed', up, vp, wp
     stop 1
  end if

  zini=0.1_prec
  zfinal=0.0999_prec
  EGMF_B0_G=(/0._prec,0._prec,1.D-20/)
  gamma_p=10._prec
  gamma_e=10._prec
  xp=0._prec
  yp=0._prec
  zp=0._prec
  xe=0._prec
  ye=0._prec
  ze=0._prec
  up=1._prec
  vp=0._prec
  wp=0._prec
  ue=1._prec
  ve=0._prec
  we=0._prec

  call trajectoireLepton(zini,zfinal,gamma_p,xp,yp,zp,up,vp,wp,1)
  call trajectoireLepton(zini,zfinal,gamma_e,xe,ye,ze,ue,ve,we,-1)
  normp=sqrt(up*up+vp*vp+wp*wp)
  norme=sqrt(ue*ue+ve*ve+we*we)
  if (abs(normp-1._prec).gt.1.D-10.or.abs(norme-1._prec).gt.1.D-10) then
     write(*,*), 'EGMF direction norm mismatch', normp, norme
     stop 1
  end if
  if (vp*ve.ge.0._prec) then
     write(*,*), 'EGMF charge sign did not reverse bending', vp, ve
     stop 1
  end if

  gamma0=10._prec
  x0=0._prec
  y0=0._prec
  zpos0=0._prec
  up=0._prec
  vp=0._prec
  wp=1._prec
  call trajectoireLepton(0.1_prec,0.0999_prec,gamma0,x0,y0,zpos0,up,vp,wp,1)
  if (gamma0.ne.gamma0.or.up.ne.up.or.vp.ne.vp.or.wp.ne.wp) then
     write(*,*), 'EGMF axis-aligned propagation produced NaN'
     stop 1
  end if

  write(*,*), 'EGMF propagation checks passed'
end program EgmfCheck
