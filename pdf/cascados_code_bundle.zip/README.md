# Cascados

Cascados is a 3D Monte-Carlo simulation written in Fortran for modeling electromagnetic cascades of very-high-energy (VHE) gamma rays propagating through the intergalactic medium. The simulation includes pair production, inverse Compton scattering, cosmological redshift/distance effects, EBL interpolation from tabulated data, and optional lepton deflection in an extragalactic magnetic field (EGMF).

## Physical Models

- **Pair production (PP):** VHE photons interact with CMB/EBL photons and produce electron-positron pairs.
- **Inverse Compton (IC) scattering:** High-energy leptons scatter background photons into higher-energy photons.
- **Cosmology:** Particle energies and propagation distances evolve with redshift.
- **EBL model:** The EBL photon density is loaded from the `EBL` and `z_EBL` input files.
- **EGMF lepton propagation:** Charged leptons can be propagated with the vector method described in `Calculs_EGMF_propagation3D.pdf`: the code evolves `u = gamma beta`, rotates the perpendicular component with Rodrigues rotation around `Bphys`, and preserves the no-synchrotron energy redshift law.

There is no electric-field propagation implementation. The EGMF implementation concerns magnetic deflection only. Synchrotron losses are also not implemented yet; enabling `UseSynchrotron` stops with a diagnostic.

## Code Architecture

- `Cascade.f95`: Main program, command-line argument handling, primary-particle setup, Monte-Carlo loop, and particle-stack processing.
- `Modules.f95`: Physical constants, shared state, particle type, stack capacity, EGMF configuration, and RNG seed.
- `RoutinesFonctions.f95`: EBL ingestion/interpolation, particle interaction routines, stack/output routines, and photon/lepton propagation.
- `Integrands.f95`: Optical-depth, interaction-rate, and cosmological integrands.
- `EgmfCheck.f95`: Makefile-backed validation driver for the EGMF propagation invariants.
- `PhysicsCheck.f95`: Makefile-backed validation driver for Planck sampling, pair-production, `mkpairs`, and spectrum range accounting.
- `bundle_code_review.py`: Bundles source files into one Markdown file for sharing with an AI or reviewer.
- `stack.f95`: Intentionally comment-only; canonical stack/output routines are in `RoutinesFonctions.f95`.

## Build And Test

This project is built with `gfortran` through the Makefile. On Windows, use `mingw32-make`.

Build the main executable:

```powershell
mingw32-make
```

Rebuild from scratch:

```powershell
mingw32-make rebuild
```

Run the EGMF propagation check:

```powershell
mingw32-make egmf-check
```

Run the physics regression checks:

```powershell
mingw32-make physics-check
```

The default build target creates `Prog.exe`. The check targets build and run `EgmfCheck.exe` and `PhysicsCheck.exe`.

## Running The Simulation

The `EBL` and `z_EBL` data files must be present in the working directory. The loader opens them read-only and stops with a clear diagnostic if either file is missing or malformed.

Run with the current defaults:

```powershell
mingw32-make run
```

The program also accepts optional runtime arguments through `RUN_ARGS`:

- argument 1: `nmax`, the number of initial photons
- argument 2: RNG seed
- argument 3: `Emin`, the primary photon energy as `log10(eV)`
- argument 4: source redshift
- argument 5: spectrum grid lower exponent `Ed`
- argument 6: spectrum grid upper exponent `Em`
- argument 7: initial direction mode, either `shared` or `independent`

The defaults preserve the historical run setup: `1000 -123456789 12.0 0.1 2.0 14.0 shared`.

Recommended deterministic smoke run:

```powershell
mingw32-make run RUN_ARGS="1 -123456789 12.0 0.1 2.0 14.0 shared"
```

The `shared` direction mode samples one isotropic primary direction and reuses it for every initial photon. The `independent` mode samples a fresh isotropic direction for each primary photon.

Some simulation parameters are still configured in source/module variables. Important EGMF knobs live in `Modules.f95`:

- `EGMF_B0_G`: uniform magnetic field in gauss; defaults to zero, preserving the no-field path.
- `B_mode=0`: `EGMF_B0_G` is interpreted as physical gauss.
- `B_mode=1`: `EGMF_B0_G` is interpreted as comoving gauss and converted as `Bphys = Bcom * (1+z)^2`.
- `UseEGMF`: enables the magnetic propagation hook when the configured field is above `B_floor_G`.
- `UseAccComptonForEGMF`: controls whether Compton accumulation is allowed when EGMF is active.

## Outputs And Generated Files

Runtime outputs:

- `Result`: Particle tracking data and final states.
- `spec_diff`: Canonical differential energy spectrum. Column 2 is already normalized by the Fortran output routine.
- `Debug2`: Runtime log, including RNG seed, runtime inputs, EGMF settings, spectrum range counters, and pair-production diagnostics.
- `Lep`: Runtime lepton file handle/output.

Build outputs:

- `Prog.exe`: Main simulation executable.
- `EgmfCheck.exe`: EGMF validation executable.
- `PhysicsCheck.exe`: Physics validation executable.
- `*.o`: Object files.
- `Modules/*.mod`: Fortran module files.

Generated review output:

- `AI_CODE_REVIEW_BUNDLE.md`: Source bundle generated by `bundle_code_review.py`.

To check generated runtime outputs for obvious invalid values:

```powershell
rg -n "NaN|nan|Infinity|Inf" Result spec_diff Debug2 Lep
```

No matches means the scan found no obvious NaN/Inf strings.

## Code Review Bundle

Generate a Markdown bundle of source files for AI or human review:

```powershell
python .\bundle_code_review.py
```

The default output is `AI_CODE_REVIEW_BUNDLE.md`. Generated/runtime outputs, object files, executables, PDFs, and data-like files are skipped by default.

To include data files explicitly:

```powershell
python .\bundle_code_review.py --output bundle.md --include-names EBL,z_EBL
```

## MATLAB Scripts

- `Plots2.m`: Visualizes angular distributions and particle arrival directions.
- `Spec.m`: Plots energy spectra from `spec_diff` without re-normalizing column 2.
- `myfun.m` and `r8vec_bracket.m`: Helper functions used during analysis.

## Known Limitations

- The particle stack is still fixed-size, though overflow is now guarded.
- Some physics/configuration knobs are still source-level module variables.
- The code still uses legacy implicit external procedure interfaces in many places; the Makefile-backed checks cover the corrected behavior, but a larger interface-module refactor remains future work.
- The EGMF implementation currently provides a uniform-field hook, not a turbulent/cell/grid field model.
- Magnetic deflection is implemented; electric-field propagation and synchrotron losses are not.
- Full `nmax=1000` runs can be noisy and slower; use small deterministic smoke runs first.
