close all
clear all
clc


xx=importdata('Result');



%scatter3(xx(:,1),xx(:,2),xx(:,3),logspace(-5,6,length(xx(:,1)))./100000,xx(:,5),'filled')
%axis([-9.3*10^26 -9.28*10^26 1.172*10^27 1.173*10^27 -9.84*10^26 -9.83*10^26])
%xlabel('x') Plots.m
%ylabel('y') 
%zlabel('z') 

ener=xx(:,3)*511000;
x=xx(:,4);
y=xx(:,5);
z=xx(:,6);


figure

longs=sqrt(x.^2+y.^2+z.^2);
phi=acos(z./longs);
theta=zeros(size(x));
ener2=zeros(size(x));

for i=1:length(y)
    
if (y(i)>=0)
theta(i)=acos(x(i)/sqrt(x(i)^2+y(i)^2));
else
    
  theta(i)=2*pi-acos(x(i)/sqrt(x(i)^2+y(i)^2))  ;
end
    i
end

theta=(theta-mean(theta))*180/pi;
phi=(phi-mean(phi))*180/pi;

hold on
% for i=1:length(y)
%  if (xx(i,9)==-1)   
% elect(i)=theta(i);
% elecp(i)=phi(i);
%  elseif (xx(i,9)==1)
% posit(i)=theta(i);
% posip(i)=phi(i);
%  else
%  phott(i)=theta(i);
%  photp(i)=phi(i);
%  end
%  i
% end


%plot3(elect,elecp,'r')
%plot3(posit,posip,'b')
scatter(theta,phi,2000*log10(ener/max(ener)+1),log10(ener),'o')

a=1.
axis([mean(theta)-a*std(theta) mean(theta)+a*std(theta) mean(phi)-a*std(theta) mean(phi)+a*std(theta)])
xlabel('\theta') 
ylabel('\phi') 

figure


[B,IX]=sort(theta);

for i=1:length(theta)
    
    ener2(i)=ener(IX(i));
   
end

ener=ener2;

hist(B,ener,50);
ph = get(gca,'children');
vn = get(ph,'Vertices');
vn(:,2) = vn(:,2) + 1;
set(ph,'Vertices',vn);

set(gca,'yscale','log')


xlabel('\theta') 
ylabel('Energie') 

%axis([-3 3 -3 3]*10^-3)
% figure
% ener=log(xx(:,5));
% plot3(x,y,xx(:,5),'+')
% a=10
% axis([mean(x)-a*std(x) mean(x)+a*std(x) mean(y)-a*std(y) mean(y)+a*std(y) mean(ener)-a*std(ener) mean(ener)+a*std(ener)])
% 

