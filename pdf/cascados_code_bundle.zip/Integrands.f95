!--------------------------------------!
!--------------------------------------!
!--------------------------------------!
!Integrands pour la production de paire!
!--------------------------------------!
!--------------------------------------!
!--------------------------------------!

!-------------------------------------------------------
!Dans lintégrale de dTau/dx pour la production de Paire
!En prenant en compte CMB et EBL
!-------------------------------------------------------

 real(prec) FUNCTION integranddtaudxPP (y,redzz)
 
  ! Modules utilisés
  USE constantes
  USE variables
  
  implicit none
  
  EXTERNAL NeInterpol 
  
  ! Declaration variables

  real(prec) :: eps, phiBar, n, serie, serieAvant, pres, beta0, w0, kk, s0
  real(prec) :: y, Egammaa, TcmbpC, redzz, nCMB, nEBL,theta

  ! il faut distingeur le beta0 et le beta00 du changement de variable de eps qui ont la même espression mais un role différent
  
  
  
  
  eps=exp(y)
  !s0=eps*((m**2.)*(c**4.)) ! non normalisé
  eps=eps

  Egammaa=Egamma*(1.+redzz)/(1.+redz)
  s0=eps*Egammaa ! doit etre sans dimentions et comme eps (voir bornes a et b) et Egamma le sont.
  beta0=sqrt((1.-1./s0))
  w0=(1.+beta0)*(1.+beta0)*s0
  pres=1.D-5 ! Presicion du calcul de la série et donc de phiBar
  TcmbpC=Tcmbp*(1.+redzz)
  
  
  !Calcul de phiBar avec la série (voir article Gould Schreder 1967)
   serie=0
   kk=0                 !initialisations
   serieAvant=10. ! valeur quelconque >0 pour rentrer dans la boucle while
   
   DO while (abs(serie-serieAvant)>pres*serieAvant)
   serieAvant=serie
   kk=kk+1.
   serie = serie + ((-1)**(kk-1))*(kk**(-2))*(w0**(-kk))
   End DO
   
   phiBar=(1.+beta0**2)*s0*log(w0)-(beta0**2)*log(w0) -log(w0)**2 -4.*beta0*s0 &
         +2.*beta0+4.*log(w0)*log(w0+1)+4.*(-(0.5)*((log(w0))**2)-(pi**2)/12.+serie)

  
  ! Distrbution des photons, au choix.
  CALL NeInterpol(eps, redzz, nEBL) ! Pour photons du CIB, à partir du fichier de Dominguez et al.

  theta=eps/TcmbpC
  nCMB=((eps/pi)**2.)*planck_inv_occupation(theta) !pour CMB corps noir

  n=nCMB+nEBL
  
  integranddtaudxPP=((exp(-y)))*n*phiBar
  
  RETURN

 END FUNCTION integranddtaudxPP

!-------------------------------------------------------
!Dans lintégrale de dTau/dx pour la production de Paire
!En ne prenant en compte que le CMB
!-------------------------------------------------------
 
 real(prec) FUNCTION integranddtaudxPPCMB (y,redzz)
 
  ! Modules utilisés
  USE constantes
  USE variables
  
  implicit none
  
  EXTERNAL NeInterpol 
  
  ! Declaration variables

  real(prec) :: eps, phiBar, n, serie, serieAvant, pres, beta0, w0, kk, s0
  real(prec) :: y, Egammaa, TcmbpC, redzz, nCMB,theta

  ! il faut distingeur le beta0 et le beta00 du changement de variable de eps qui ont la même espression mais un role différent
  
  
  
  
  eps=exp(y)
  !s0=eps*((m**2.)*(c**4.)) ! non normalisé
  eps=eps
  Egammaa=Egamma*(1.+redzz)/(1.+redz)
  s0=eps*Egammaa ! doit etre sans dimentions et comme eps (voir bornes a et b) et Egamma le sont.
  beta0=sqrt((1.-1./s0))
  w0=(1.+beta0)*(1.+beta0)*s0
  pres=1.D-5 ! Presicion du calcul de la série et donc de phiBar
  TcmbpC=Tcmbp*(1.+redzz)
  
  
  !Calcul de phiBar avec la série (voir article Gould Schreder 1967)
   serie=0
   kk=0                 !initialisations
   serieAvant=10. ! valeur quelconque >0 pour rentrer dans la boucle while
   
   DO while (abs(serie-serieAvant)>pres*serieAvant)
   serieAvant=serie
   kk=kk+1.
   serie = serie + ((-1)**(kk-1))*(kk**(-2))*(w0**(-kk))
   End DO
   
   phiBar=(1.+beta0**2)*s0*log(w0)-(beta0**2)*log(w0) -log(w0)**2 -4.*beta0*s0 &
         +2.*beta0+4.*log(w0)*log(w0+1)+4.*(-(0.5)*((log(w0))**2)-(pi**2)/12.+serie)

  
  ! Distrbution des photons, au choix.
  theta=eps/TcmbpC
  nCMB=((eps/pi)**2.)*planck_inv_occupation(theta) !pour CMB corps noir
  n=nCMB
  
  integranddtaudxPPCMB=((exp(-y)))*n*phiBar
  
  RETURN

 END FUNCTION integranddtaudxPPCMB

!-------------------------------------------------------
!Dans lintégrale de dTau/dx pour la production de Paire
!En ne prenant en compte que l'EBL
!-------------------------------------------------------
 
 real(prec) FUNCTION integranddtaudxPPEBL (y,redzz)
 
  ! Modules utilisés
  USE constantes
  USE variables
  
  implicit none
  
  EXTERNAL NeInterpol 
  
  ! Declaration variables

  real(prec) :: eps, phiBar, n, serie, serieAvant, pres, beta0, w0, kk, s0
  real(prec) :: y, Egammaa, TcmbpC, redzz, nEBL

  ! il faut distingeur le beta0 et le beta00 du changement de variable de eps qui ont la même espression mais un role différent
  
  
  
  
  eps=exp(y)
  !s0=eps*((m**2.)*(c**4.)) ! non normalisé
  eps=eps
  Egammaa=Egamma*(1.+redzz)/(1.+redz)
  s0=eps*Egammaa ! doit etre sans dimentions et comme eps (voir bornes a et b) et Egamma le sont.
  beta0=sqrt((1.-1./s0))
  w0=(1.+beta0)*(1.+beta0)*s0
  pres=1.D-5 ! Presicion du calcul de la série et donc de phiBar
  TcmbpC=Tcmbp*(1.+redzz)
  
  
  !Calcul de phiBar avec la série (voir article Gould Schreder 1967)
   serie=0
   kk=0                 !initialisations
   serieAvant=10. ! valeur quelconque >0 pour rentrer dans la boucle while
   
   DO while (abs(serie-serieAvant)>pres*serieAvant)
   serieAvant=serie
   kk=kk+1.
   serie = serie + ((-1)**(kk-1))*(kk**(-2))*(w0**(-kk))
   End DO
   
   phiBar=(1.+beta0**2)*s0*log(w0)-(beta0**2)*log(w0) -log(w0)**2 -4.*beta0*s0 &
         +2.*beta0+4.*log(w0)*log(w0+1)+4.*(-(0.5)*((log(w0))**2)-(pi**2)/12.+serie)

  
  ! Distrbution des photons, au choix.
  CALL NeInterpol(eps, redzz, nEBL) ! Pour photons du CIB, à partir du fichier de Dominguez et al.
  n=nEBL
  
  integranddtaudxPPEBL=((exp(-y)))*n*phiBar
  
  RETURN

 END FUNCTION integranddtaudxPPEBL



!------------------------------------------------------
!Dans l'intégrale de Tau pour la production de paire
!------------------------------------------------------

 real(prec) FUNCTION integrandTauPP (reddz)
  USE constantes
  USE variables
  
  implicit none
  
  ! Declarations fonctions utilisées
  
  real(prec) qgaussZ
  EXTERNAL qgaussZ 
  real(prec) integranddtaudxPP
  EXTERNAL integranddtaudxPP 
  
  
  ! Declaration variables

  real(prec) :: aa, bb
  real(prec) :: reddz, dtaudxPP, Egammaa
  
  !redz = borne sup, reddz = variable d'intégration
  
  ! Prise en compte cosmo

  Egammaa=Egamma*(1.+reddz)/(1.+redz) ! Il ne faut pas modifier la variabe Egamma pour éviter bug; de même pour redz
  
  aa=log(1./Egammaa) ! Bornes adimentionnées car Egamma adimentionné
  !bb=log(1D+15*1./Egammaa)
  
  bb=log(max(pairprod_eps_upper_floor,1./Egammaa))
  
  if (aa==bb) then
  dtaudxPP=0.
  else
  dtaudxPP=qgaussZ(integranddtaudxPP, aa, bb, reddz)
  end if
  integrandTauPP=(1/(Egammaa**2))*dtaudxPP/((1.+reddz)*sqrt((omegaM*((1.+reddz)**3)+(omegaK)*((1.+reddz)**2)+omegaL)))

  RETURN

 END FUNCTION integrandTauPP


!------------------------------------!
!------------------------------------!
!------------------------------------!
!Integrands pour la diffusion Compton!
!------------------------------------!
!------------------------------------!
!------------------------------------!

!--------------------------------------------------
!Dans lintégrale de I_gamma de la diffusion compton
!--------------------------------------------------
 real(prec) FUNCTION integrandx(x)
 
  ! Modules utilisés
  USE constantes
  USE variables
  
  implicit none
  
  EXTERNAL NeInterpol 
  
  ! Declaration variables

  real(prec) :: x
  
  ! Distrbution des photons, au choix.
  !CALL NeInterpol(eps, redzz, n) ! Pour photons du CIB, à partir du fichier de Dominguez et al.
  !n=((eps/pi)**2.)*((exp(eps/TcmbpC)-1.)**(-1.)) !pour CMB corps noir
  
  integrandx=((1.-4./x-8./(x**2))*log(1.+x)+8./x-1./(2.*((1.+x)**2))+0.5)
  
  RETURN

 END FUNCTION integrandx


!--------------------------------------------------
!Dans lintégrale de dTau/dx de la diffusion compton
!En prenant en Compte CMB + EBL
!--------------------------------------------------
 real(prec) FUNCTION integranddtaudxCom (y,reddz)
 
  ! Modules utilisés
  USE constantes
  USE variables
  
  implicit none
  real(prec) integrandx
  EXTERNAL integrandx 
  EXTERNAL NeInterpol
  real(prec) qgauss,eintegcom
  EXTERNAL qgauss
  
  ! Declaration variables

  real(prec) :: a, b, n, beta, eps, nEBL, nCMB,y, theta
  real(prec) :: TcmbpC, x, reddz,xx,w,gamma
  
  
  eps=exp(y)
  TcmbpC=Tcmb*k*(1.+reddz)
  


  gamma=Eelec/(m*c*c)
  gamma=sqrt(1.+(gamma**2-1.)*((1.+reddz)/(1.+zcoresE))**2)
  

  theta=eps/TcmbpC
  nCMB=((hb*c)**(-3))*((eps/pi)**2.)*planck_inv_occupation(theta) !pour CMB corps noir

  eps=eps/(m*c*c)
  
  CALL NeInterpol(eps, reddz, nEBL) ! Pour photons du CIB, à partir du fichier de Dominguez et al.
  eps=eps*m*c*c
  

  
  nEBL=nEBL*(((hb*c)**(-3))*(((m*c*c))**2))

!Accumulation Compton

eintegcom=SeuilAccCompton/(4./3.*2.7*Tcmbp*(1.+zcoresE))-2.

xi1=1.

if (EelecAvant.lt.eintegcom) then !CMB

 xi1=(eintegcom+2.)/(EelecAvant+2.)

end if  
eintegcom=SeuilAccCompton/(4./3.*2.7*ebl_accum_reference_eps*(1.+zcoresE))-2.
xi2=1.
if (EelecAvant.lt.eintegcom) then !EBL

 xi2=(eintegcom+2.)/(EelecAvant+2.)

end if  

if (UseEGMF.and.sqrt(dot_product(EGMF_B0_G,EGMF_B0_G)).gt.B_floor_G.and.(.not.UseAccComptonForEGMF)) then
 xi1=1.
 xi2=1.
end if

  n=nCMB/xi1+nEBL/xi2
  !write(*,*), nEBL,nCMB,nEBL+nCMB
  
  !beta=sqrt(1-((m**2)*(c**4))/(Eelecc**2))
  
  
  w=eps/(m*c**2)
  
  x=2.*gamma*w
  
  !write(*,*),x
  
  if (x<1.D-3) then
  xx=sigmaT*(1.-x+(13./10.)*x**2-(133./80.)*x**3+(143./70.)*x**4)
  integranddtaudxCom=n*xx*exp(y)

  
  else
  
  beta=sqrt(1.-gamma**(-2))
  b=2.*gamma*(1.+beta)*w
  a=2.*gamma*(1.-beta)*w

  xx=qgauss(integrandx,a,b)

  !xx=(3*c*sigmaT)*(1./(4.*x))*((1.-4./x-8./(x**2))*log(1.+x)+8./x-1./(2.*((1.+x)**2))+0.5)
  integranddtaudxCom=(3.*sigmaT*n/(32.*gamma**2*beta*w**2))*xx*exp(y)


  end if
 
       
  !integranddtaudxCom=((1+reddz)**3)*n*xx
  



 END FUNCTION integranddtaudxCom

!--------------------------------------------------
!Dans lintégrale de dTau/dx de la diffusion compton
!En prenant en Compte CMB uniquement
!--------------------------------------------------
 real(prec) FUNCTION integranddtaudxComCMB (y,reddz)
 
  ! Modules utilisés
  USE constantes
  USE variables
  
  implicit none
  real(prec) integrandx
  EXTERNAL integrandx 
  EXTERNAL NeInterpol
  real(prec) qgauss
  EXTERNAL qgauss
  
  ! Declaration variables

  real(prec) :: a, b, n, beta, eps, nCMB,y, theta
  real(prec) :: TcmbpC,x, reddz,xx,w,gamma
  
  
  eps=exp(y)
  TcmbpC=Tcmb*k*(1.+reddz)

  gamma=Eelec/(m*c*c)
  gamma=sqrt(1.+(gamma**2-1.)*((1.+reddz)/(1.+zcoresE))**2)

  theta=eps/TcmbpC
  nCMB=((hb*c)**(-3))*((eps/pi)**2.)*planck_inv_occupation(theta) !pour CMB corps noir
  
  !eps=eps/(m*c*c)
  !CALL NeInterpol(eps, reddz, nEBL) ! Pour photons du CIB, à partir du fichier de Dominguez et al.
  !eps=eps*m*c*c
  
  
  !nEBL=((1+reddz)**3)*nEBL*(((hb*c)**(-3))*(((m*c*c))**2))



  n=nCMB/xi1
  !write(*,*), nEBL,nCMB,nEBL+nCMB
  
  !beta=sqrt(1-((m**2)*(c**4))/(Eelecc**2))
  

  
  
  w=eps/(m*c**2)
  
  x=2.*gamma*w
  
  !write(*,*),x
  
  if (x<1.D-3) then
  xx=sigmaT*(1.-x+(13./10.)*x**2-(133./80.)*x**3+(143./70.)*x**4)
  integranddtaudxComCMB=n*xx*exp(y)
  else
  
  beta=sqrt(1.-gamma**(-2))
  b=2.*gamma*(1.+beta)*w
  a=2.*gamma*(1.-beta)*w
  
  xx=qgauss(integrandx,a,b)
  !xx=(3*c*sigmaT)*(1./(4.*x))*((1.-4./x-8./(x**2))*log(1.+x)+8./x-1./(2.*((1.+x)**2))+0.5)
  integranddtaudxComCMB=(3.*sigmaT*n/(32.*gamma**2*beta*w**2))*xx*exp(y)
  
  end if
 
  
  !integranddtaudxCom=((1+reddz)**3)*n*xx
  
  
  RETURN

 END FUNCTION integranddtaudxComCMB

!--------------------------------------------------
!Dans lintégrale de dTau/dx de la diffusion compton
!En prenant en Compte EBL uniquement
!--------------------------------------------------
 real(prec) FUNCTION integranddtaudxComEBL (y,reddz)
 
  ! Modules utilisés
  USE constantes
  USE variables
  
  implicit none
  real(prec) integrandx
  EXTERNAL integrandx 
  EXTERNAL NeInterpol
  real(prec) qgauss
  EXTERNAL qgauss
  
  ! Declaration variables

  real(prec) :: a, b, n, beta, eps, nEBL,y, theta
  real(prec) :: TcmbpC, x, reddz,xx,w,gamma
  
  
  eps=exp(y)
  TcmbpC=Tcmb*k*(1.+reddz)


  !nCMB=((hb*c)**(-3))*((eps/pi)**2.)*((exp(eps/TcmbpC)-1.)**(-1.)) !pour CMB corps noir
  theta=eps/(Tcmb*k*(1.+reddz))
  !if (eps/(Tcmb*k*(1+reddz))<1D-2) then
  
  !nCMB=((hb*c)**(-3))*((eps/pi)**2.)*((theta+(theta**2)/2.+(theta)**3)/6.+((theta)**4)/24.)**(-1.)
  
  !end if
  
  eps=eps/(m*c*c)
  CALL NeInterpol(eps, reddz, nEBL) ! Pour photons du CIB, à partir du fichier de Dominguez et al.
  eps=eps*m*c*c
  
  
  nEBL=nEBL*(((hb*c)**(-3))*(((m*c*c))**2))


  n=nEBL/xi2 
  !write(*,*), nEBL,nCMB,nEBL+nCMB
  
  !beta=sqrt(1-((m**2)*(c**4))/(Eelecc**2))
  
  gamma=Eelec/(m*c*c)
  gamma=sqrt(1.+(gamma**2-1.)*((1.+reddz)/(1.+zcoresE))**2)
  
  
  w=eps/(m*c**2)
  
  x=2.*gamma*w
  
  !write(*,*),x
  
  if (x<1.D-3) then
  xx=sigmaT*(1.-x+(13./10.)*x**2-(133./80.)*x**3+(143./70.)*x**4)
  integranddtaudxComEBL=n*xx*exp(y)
  else
  
  beta=sqrt(1.-gamma**(-2))
  b=2.*gamma*(1.+beta)*w
  a=2.*gamma*(1.-beta)*w
  
  xx=qgauss(integrandx,a,b)
  !xx=(3*c*sigmaT)*(1./(4.*x))*((1.-4./x-8./(x**2))*log(1.+x)+8./x-1./(2.*((1.+x)**2))+0.5)
  integranddtaudxComEBL=(3.*sigmaT*n/(32.*gamma**2*beta*w**2))*xx*exp(y)
  
  end if
 
  
  !integranddtaudxCom=((1+reddz)**3)*n*xx
  
  
  RETURN

 END FUNCTION integranddtaudxComEBL


!--------------------------------------------------
!Dans lintégrale de Tau pour la diffusion Compton
!--------------------------------------------------

 real(prec) FUNCTION integrandTauCom (reddz)
  USE constantes
  USE variables
  
  implicit none
  
  ! Declaration variables

  real(prec) :: reddz, dtaudxCom,aa,bb
  
  ! Declarations fonctions utilisées
  
  real(prec) qgaussZ
  EXTERNAL qgaussZ
  real(prec) integranddtaudxCom
  EXTERNAL integranddtaudxCom 
  


  aa=log(compton_eps_min)

  bb=log(compton_eps_max)

  
  dtaudxCom=qgaussZ(integranddtaudxCom,aa,bb,reddz)


integrandTauCom=dtaudxCom/((1.+reddz)*sqrt((omegaM*((1.+reddz)**3)+(omegaK)*((1.+reddz)**2)+omegaL)))
  RETURN

 END FUNCTION integrandTauCom


!----------------------------------------------------------------
!Pour l'integrale de la convertion du redshift en temps
!----------------------------------------------------------------

 real(prec) FUNCTION integrandt (reddz)
  USE constantes, only : omegaM,omegaK,omegaL, prec
  
  implicit none

  real(prec) :: reddz
  integrandt=1./((1.+reddz)*sqrt((omegaM*((1.+reddz)**3)+(omegaK)*((1.+reddz)**2)+omegaL)))
  RETURN

 END FUNCTION integrandt

!----------------------------------------------------------------
!Dans l'intégrale de la distance parcourrue par un photon
!----------------------------------------------------------------
 real(prec) FUNCTION integrandR (reddz)
  USE constantes, only : omegaM,omegaK,omegaL,prec
  
  implicit none

  real(prec) :: reddz
  integrandR=1./(sqrt((omegaM*((1.+reddz)**3)+(omegaK)*((1.+reddz)**2)+omegaL)))
  RETURN

 END FUNCTION integrandR

!----------------------------------------------------------------
!Dans l'intégrale de la distance parcourrue par un lepton
!----------------------------------------------------------------

 real(prec) FUNCTION integrandDr (x, z1,gamma1)
  USE constantes, only : omegaM,omegaK,omegaL,prec
  
  implicit none

  real(prec) :: x, z1,gamma1

  integrandDr=sqrt((1.-1./(1.+((1.+x)/(1+z1))**2*(Gamma1**2-1)))/(OmegaM*(1+x)**3+OmegaL))
  RETURN

 END FUNCTION integrandDr

!----------------------------------------------------------------
!Dans pour la moyenne de z
!----------------------------------------------------------------
 real(prec) FUNCTION integrandzz (reddz)
  USE constantes, only : omegaM,omegaK,omegaL,prec
  
  implicit none

  real(prec) :: reddz
  integrandzz=((1.+reddz)**3)/(sqrt((omegaM*((1.+reddz)**3)+(omegaK)*((1.+reddz)**2)+omegaL)))
  RETURN

 END FUNCTION integrandzz
