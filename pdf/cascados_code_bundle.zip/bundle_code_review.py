#!/usr/bin/env python3
"""Bundle project source into one Markdown file for AI/code review."""

from __future__ import annotations

import argparse
from datetime import datetime, timezone
from pathlib import Path


DEFAULT_OUTPUT = "AI_CODE_REVIEW_BUNDLE.md"

DEFAULT_INCLUDE_SUFFIXES = {
    ".f",
    ".f90",
    ".f95",
    ".for",
    ".m",
    ".py",
    ".md",
    ".mk",
    ".txt",
}

DEFAULT_INCLUDE_NAMES = {
    "Makefile",
}

DEFAULT_EXCLUDE_SUFFIXES = {
    ".exe",
    ".o",
    ".obj",
    ".mod",
    ".pdf",
    ".png",
    ".jpg",
    ".jpeg",
    ".gif",
    ".zip",
    ".7z",
    ".tar",
    ".gz",
}

DEFAULT_EXCLUDE_NAMES = {
    DEFAULT_OUTPUT,
    "Result",
    "Spec",
    "Lep",
    "Debug2",
    "spec_diff",
}

DEFAULT_EXCLUDE_DIRS = {
    ".git",
    "__pycache__",
    ".pytest_cache",
    ".mypy_cache",
    ".ruff_cache",
}

LANG_BY_SUFFIX = {
    ".f": "fortran",
    ".f90": "fortran",
    ".f95": "fortran",
    ".for": "fortran",
    ".m": "matlab",
    ".py": "python",
    ".md": "markdown",
    ".mk": "make",
    ".txt": "text",
}


def parse_csv(value: str) -> set[str]:
    return {item.strip() for item in value.split(",") if item.strip()}


def is_binary(path: Path, sample_size: int = 4096) -> bool:
    try:
        chunk = path.read_bytes()[:sample_size]
    except OSError:
        return True
    return b"\x00" in chunk


def should_include(
    path: Path,
    root: Path,
    output: Path,
    include_suffixes: set[str],
    include_names: set[str],
    exclude_suffixes: set[str],
    exclude_names: set[str],
    exclude_dirs: set[str],
) -> tuple[bool, str]:
    rel = path.relative_to(root)
    if path.resolve() == output.resolve():
        return False, "output file"
    if any(part in exclude_dirs for part in rel.parts[:-1]):
        return False, "excluded directory"
    if path.name in exclude_names:
        return False, "excluded generated/runtime file"
    if path.suffix.lower() in exclude_suffixes:
        return False, "excluded suffix"
    if path.name in include_names or path.suffix.lower() in include_suffixes:
        if is_binary(path):
            return False, "binary-looking content"
        return True, "included"
    return False, "not source by default"


def read_text_lossy(path: Path) -> str:
    raw = path.read_bytes()
    return raw.decode("utf-8", errors="replace")


def fence_language(path: Path) -> str:
    if path.name == "Makefile":
        return "make"
    return LANG_BY_SUFFIX.get(path.suffix.lower(), "text")


def build_tree(paths: list[Path], root: Path) -> str:
    return "\n".join(f"- `{path.relative_to(root).as_posix()}`" for path in paths)


def bundle(args: argparse.Namespace) -> None:
    root = Path(args.root).resolve()
    output = Path(args.output)
    if not output.is_absolute():
        output = root / output
    output = output.resolve()

    include_suffixes = DEFAULT_INCLUDE_SUFFIXES | parse_csv(args.include_suffixes)
    include_names = DEFAULT_INCLUDE_NAMES | parse_csv(args.include_names)
    exclude_suffixes = DEFAULT_EXCLUDE_SUFFIXES | parse_csv(args.exclude_suffixes)
    exclude_names = DEFAULT_EXCLUDE_NAMES | parse_csv(args.exclude_names)
    exclude_dirs = DEFAULT_EXCLUDE_DIRS | parse_csv(args.exclude_dirs)

    included: list[Path] = []
    skipped: list[tuple[Path, str]] = []

    for path in sorted(root.rglob("*"), key=lambda p: p.relative_to(root).as_posix().lower()):
        if not path.is_file():
            continue
        ok, reason = should_include(
            path,
            root,
            output,
            include_suffixes,
            include_names,
            exclude_suffixes,
            exclude_names,
            exclude_dirs,
        )
        if ok:
            included.append(path)
        else:
            skipped.append((path, reason))

    generated_at = datetime.now(timezone.utc).isoformat(timespec="seconds")
    lines: list[str] = [
        "# AI Code Review Bundle",
        "",
        f"- Generated at: `{generated_at}`",
        f"- Root: `{root}`",
        f"- Included files: `{len(included)}`",
        f"- Skipped files: `{len(skipped)}`",
        "",
        "## How To Read This",
        "",
        "This file bundles the project source for review by another AI or human reviewer.",
        "Generated/runtime outputs, binaries, object files, PDFs, and large data-like files are skipped by default.",
        "",
        "## Included File Tree",
        "",
        build_tree(included, root) if included else "_No files included._",
        "",
        "## Skipped Files",
        "",
    ]

    if skipped:
        lines.extend(
            f"- `{path.relative_to(root).as_posix()}`: {reason}"
            for path, reason in skipped
        )
    else:
        lines.append("_No files skipped._")

    lines.extend(["", "## File Contents", ""])

    for path in included:
        rel = path.relative_to(root).as_posix()
        content = read_text_lossy(path).rstrip()
        lines.extend(
            [
                f"### `{rel}`",
                "",
                f"```{fence_language(path)}",
                content,
                "```",
                "",
            ]
        )

    output.write_text("\n".join(lines), encoding="utf-8", newline="\n")
    print(f"Wrote {output} with {len(included)} files.")


def main() -> None:
    parser = argparse.ArgumentParser(
        description="Bundle source files into a single Markdown file for AI review."
    )
    parser.add_argument("--root", default=".", help="Project root to scan.")
    parser.add_argument("--output", default=DEFAULT_OUTPUT, help="Markdown bundle path.")
    parser.add_argument(
        "--include-suffixes",
        default="",
        help="Comma-separated extra suffixes to include, for example .jl,.toml.",
    )
    parser.add_argument(
        "--include-names",
        default="",
        help="Comma-separated extra exact file names to include.",
    )
    parser.add_argument(
        "--exclude-suffixes",
        default="",
        help="Comma-separated extra suffixes to exclude.",
    )
    parser.add_argument(
        "--exclude-names",
        default="",
        help="Comma-separated extra exact file names to exclude.",
    )
    parser.add_argument(
        "--exclude-dirs",
        default="",
        help="Comma-separated extra directory names to exclude.",
    )
    bundle(parser.parse_args())


if __name__ == "__main__":
    main()
