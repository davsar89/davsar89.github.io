function y = myfun(x) 
y = ((1+x).^3)./sqrt(0.3*(1+x).^3+0.7);