program PhysicsCheck
  use constantes
  use variables
  implicit none

  integer :: i

  call gauleg(ngp,xabsc,weig)
  iseed=-123456789

  call check_planck_helper()
  call check_pair_production()
  call check_mkpairs()
  call check_register_range()

  write(*,*), 'Physics checks passed'

contains

  logical function finite_value(x)
    real(prec), intent(in) :: x
    finite_value = x.eq.x .and. abs(x).lt.huge(x)
  end function finite_value

  subroutine require(condition,message)
    logical, intent(in) :: condition
    character(len=*), intent(in) :: message
    if (.not.condition) then
       write(*,*), trim(message)
       stop 1
    end if
  end subroutine require

  subroutine check_planck_helper()
    real(prec) :: theta, expected, got, relerr, denom

    theta=1.D-8
    denom=theta + theta**2/2._prec + theta**3/6._prec + theta**4/24._prec
    expected=1._prec/denom
    got=planck_inv_occupation(theta)
    relerr=abs(got-expected)/expected
    call require(relerr.lt.1.D-12, 'Planck helper small-theta series mismatch')

    theta=1.D-4
    expected=1._prec/(exp(theta)-1._prec)
    got=planck_inv_occupation(theta)
    relerr=abs(got-expected)/expected
    call require(relerr.lt.1.D-8, 'Planck helper direct comparison mismatch')

    theta=1.D-2
    expected=1._prec/(exp(theta)-1._prec)
    got=planck_inv_occupation(theta)
    relerr=abs(got-expected)/expected
    call require(relerr.lt.1.D-12, 'Planck helper threshold comparison mismatch')
  end subroutine check_planck_helper

  subroutine check_pair_production()
    real(prec) :: hnu1,hnu2,mu,gama,betaca,beta
    real(prec) :: uu(2),vv(2),ww(2),norm1,norm2

    hnu1=20._prec
    hnu2=2._prec
    mu=-1._prec
    gama=sqrt(hnu1*hnu2*(1._prec-mu)/2._prec)
    betaca=1._prec-gama**(-2)
    beta=sqrt(betaca)
    uu=(/0._prec,0._prec/)
    vv=(/0._prec,0._prec/)
    ww=(/1._prec,-1._prec/)

    call pair_production(hnu1,hnu2,uu,vv,ww,mu,gama,betaca,beta)
    norm1=sqrt(uu(1)**2+vv(1)**2+ww(1)**2)
    norm2=sqrt(uu(2)**2+vv(2)**2+ww(2)**2)

    call require(finite_value(hnu1).and.finite_value(hnu2), 'pair_production energies are not finite')
    call require(hnu1.gt.1._prec.and.hnu2.gt.1._prec, 'pair_production energies are below rest energy')
    call require(finite_value(norm1).and.finite_value(norm2), 'pair_production norms are not finite')
    call require(abs(norm1-1._prec).lt.1.D-8, 'pair_production first direction is not normalized')
    call require(abs(norm2-1._prec).lt.1.D-8, 'pair_production second direction is not normalized')
  end subroutine check_pair_production

  subroutine check_mkpairs()
    real(prec) :: ep1,ep2,u1,v1,w1,u2,v2,w2,norm1,norm2
    logical :: erreur

    duetoCMB=.true.
    call mkpairs(1.D10,0._prec,0._prec,1._prec,0.1_prec,&
        ep1,u1,v1,w1,ep2,u2,v2,w2,erreur)
    norm1=sqrt(u1*u1+v1*v1+w1*w1)
    norm2=sqrt(u2*u2+v2*v2+w2*w2)

    call require(.not.erreur, 'mkpairs returned erreur')
    call require(finite_value(ep1).and.finite_value(ep2), 'mkpairs energies are not finite')
    call require(ep1.gt.0._prec.and.ep2.gt.0._prec, 'mkpairs energies are not positive')
    call require(abs(norm1-1._prec).lt.1.D-8, 'mkpairs first direction is not normalized')
    call require(abs(norm2-1._prec).lt.1.D-8, 'mkpairs second direction is not normalized')
  end subroutine check_mkpairs

  subroutine check_register_range()
    real(prec) :: Ed,Em

    spec=0._prec
    grille=0._prec
    spec_underflow_count=0
    spec_overflow_count=0
    Ed=2._prec
    Em=14._prec
    do i=1,n_bin
       grille(i)=10._prec**(((Ed-Em)/(1._prec-n_bin))*(i-1._prec)+Ed)
    end do

    call register(1.D-6,1._prec,0)
    call register(1.D10,1._prec,0)
    call register(1.D6,1._prec,0)

    call require(spec_underflow_count.eq.1, 'register underflow counter mismatch')
    call require(spec_overflow_count.eq.1, 'register overflow counter mismatch')
    call require(sum(spec(:,:)).gt.0._prec, 'register in-range value was not recorded')
  end subroutine check_register_range

end program PhysicsCheck
