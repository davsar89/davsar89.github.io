! This file is intentionally comment-only.
!
! The canonical stack and spectrum routines are implemented in
! RoutinesFonctions.f95 and are the only versions built by Makefile:
!   - get_particle
!   - store_particle
!   - register
!   - user_output
!
! Keeping duplicate external subroutines here caused a maintenance trap:
! adding stack.f95 to the build would define the same symbols twice.
