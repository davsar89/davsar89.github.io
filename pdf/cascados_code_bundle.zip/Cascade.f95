program Cascade                        

USE constantes 
USE variables

implicit none

!    Declaration des fonctions

  REAL(prec) integrandt
  EXTERNAL integrandt
  REAL(prec) integrandR
  EXTERNAL integrandR
  REAL(prec) qgauss
  EXTERNAL qgauss
  REAL(prec) qgaussZ
  EXTERNAL qgaussZ
  REAL(prec) integrandzz
  EXTERNAL integrandzz
  REAL(prec) ran0
  EXTERNAL ran0
  
! Declaration des subroutines
  EXTERNAL gauleg 
  EXTERNAL r8vec_bracket
  EXTERNAL EBLLecture
  EXTERNAL CalculZintPairprod
  External CalculZintCompton
  EXTERNAL distancePhoton
  external isophotcompton
  external TrouveZlimPhot
  external TrouveZlimLep
  external isotrop
  external get_particle
  external register
  external user_output

! Declrations variabes

  real(4), dimension(2) :: tarray
  REAL(prec) :: a, b, Emin,initial_redshift,redshift,energie,xx,yy,zz,u,v,w,poids
  REAL(prec) :: z0, t0, lim,Ed,Em,uuu,vvv,www
  REAL(prec)::  dist,inte
  REAL(prec) :: l,zlim,diravU,diravV,diravW,cosalpharxi,sinalpha,ll,angle_den
  real(prec) :: energieE1,uE1,vE1,wE1,energieE2,uE2,vE2,wE2,energiePhot,uPhot,vPhot,wPhot
  logical :: erreur,egmf_active ! s'il y a une erreur quelque part
  Real::t1, t2
  integer :: natureElec,naturePosi,naturePhot,nature,j,nmax
  integer :: ios
  character(len=64) :: arg
  character(len=32) :: direction_mode

!----------------------------------
!Initialisations
!----------------------------------
call ETIME(tarray, t1) !Pour calculer le temps pendant lequel tourne le programme

 open (unit=11,file="Result") ! Resultats generaux
 open (unit=10,file="Debug2") ! Debug
 open (unit=12,file="Lep") !Savoir ou et quand les Leptons sont crees
	
    TaillePile=0
    spec=0._prec
    grille=0._prec
    spec_underflow_count=0
    spec_overflow_count=0
    pairprod_fallback_count=0
    pairprod_norm_warning_count=0
    xi=1._prec
    xi1=1._prec
    xi2=1._prec
    frac=1._prec
    duetoCMB=.true.
    vaInteragir=.false.
    nmax=1000 !nombre maximal de photons initiaux
    Emin=12.0_prec
    initial_redshift=0.1_prec
    Ed=2._prec
    Em=14._prec
    direction_mode='shared'
    call get_command_argument(1,arg)
    if (len_trim(arg).gt.0) then
       read(arg,*,iostat=ios) nmax
       if (ios.ne.0.or.nmax.le.0) then
          write(*,*), 'Argument nmax invalide: ', trim(arg)
          stop 1
       end if
    end if
    call get_command_argument(2,arg)
    if (len_trim(arg).gt.0) then
       read(arg,*,iostat=ios) iseed
       if (ios.ne.0) then
          write(*,*), 'Argument seed invalide: ', trim(arg)
          stop 1
       end if
    end if
    call get_command_argument(3,arg)
    if (len_trim(arg).gt.0) then
       read(arg,*,iostat=ios) Emin
       if (ios.ne.0) then
          write(*,*), 'Argument Emin invalide: ', trim(arg)
          stop 1
       end if
    end if
    call get_command_argument(4,arg)
    if (len_trim(arg).gt.0) then
       read(arg,*,iostat=ios) initial_redshift
       if (ios.ne.0.or.initial_redshift.lt.0._prec) then
          write(*,*), 'Argument redshift invalide: ', trim(arg)
          stop 1
       end if
    end if
    call get_command_argument(5,arg)
    if (len_trim(arg).gt.0) then
       read(arg,*,iostat=ios) Ed
       if (ios.ne.0) then
          write(*,*), 'Argument Ed invalide: ', trim(arg)
          stop 1
       end if
    end if
    call get_command_argument(6,arg)
    if (len_trim(arg).gt.0) then
       read(arg,*,iostat=ios) Em
       if (ios.ne.0) then
          write(*,*), 'Argument Em invalide: ', trim(arg)
          stop 1
       end if
    end if
    call get_command_argument(7,arg)
    if (len_trim(arg).gt.0) then
       if (len_trim(arg).gt.len(direction_mode)) then
          write(*,*), 'Argument direction mode trop long: ', trim(arg)
          stop 1
       end if
       direction_mode=adjustl(arg(1:len_trim(arg)))
    end if
    if (trim(direction_mode).ne.'shared'.and.trim(direction_mode).ne.'independent') then
       write(*,*), 'Argument direction mode invalide: ', trim(direction_mode)
       stop 1
    end if
    egmf_active=UseEGMF.and.sqrt(dot_product(EGMF_B0_G,EGMF_B0_G)).gt.B_floor_G
    write(unit=10,fmt=*), 'Runtime nmax = ', nmax
    write(unit=10,fmt=*), 'RNG seed = ', iseed
    write(unit=10,fmt=*), 'Runtime Emin log10(eV) = ', Emin
    write(unit=10,fmt=*), 'Runtime initial redshift = ', initial_redshift
    write(unit=10,fmt=*), 'Runtime grid Ed, Em = ', Ed, Em
    write(unit=10,fmt=*), 'Runtime direction mode = ', trim(direction_mode)
    write(unit=10,fmt=*), 'EGMF UseEGMF, active, B_mode, B0_G = ', UseEGMF, egmf_active, B_mode, EGMF_B0_G

    naturePhot=0
    natureElec=-1
    naturePosi=1

!Direction isotrope aleatoire partagee par les photons initiaux
if (trim(direction_mode).eq.'shared') then
   call isotrop(uuu,vvv,www)
end if
call EBLLecture ! lecture et convertion du fichier de Dominguez et al.
call gauleg(ngp, xabsc, weig) ! Calcul des position et poids pour Gauss-Legendre

a=0.
b=2.

inte=qgauss(integrandzz, a, b)
write(*,*), inte

do j=1,n_bin

Grille(j)=10.**(((Ed-Em)/(1.-n_bin))*(j-1.)+Ed)

end do

!les energies des photons gamma et des elecrons sont dans des variables globales Egamma et Eelec
!qui doivent etre mis a jour avant chaque calcul d'interaction.


do j=1,nmax
!--------------------------------------
! Caracteristiques photon gamma initial
!--------------------------------------

par(1)%redshift=initial_redshift !Redshift emission
lim=0.
l=(c/H0)*qgauss(integrandR, lim, par(1)%redshift)  ! distance a laquelle il se trouve de la Terre
Egamma=(m*c*c)/(510.998918*1000)*10**(Emin) ! Energie du photon gamma en cgs

par(1)%nature=naturePhot ! C'est un photon
par(1)%ener=Egamma/(m*c*c) ! On adimentionne Egamma
! Position et direction initiale du photon gamma
par(1)%x=0.
par(1)%y=0.
par(1)%z=0.
if (trim(direction_mode).eq.'independent') then
   call isotrop(par(1)%u,par(1)%v,par(1)%w)
else
   par(1)%u=uuu
   par(1)%v=vvv
   par(1)%w=www
end if

par(1)%poids=1.

! Temps correspondant ï¿½ z0 (comptï¿½ depuis aujourd'hui jusqu'au moment d'ï¿½mission
a=0.
b=par(1)%redshift          
t0=(1./H0)*qgauss(integrandt, a, b)/(3600.*24.*365.25*1.D9) !en Gyr


                
    
write(*,*), 'le photon Gamma initial est emis a un redshift z = ', par(1)%redshift, 'soit il y a', t0,'milliard d annes'
write(*,*), 'Au moment de son emission il a une energie de 10^',Emin, 'eV' 
write(*,*),'! distance a laquelle il se trouve de la Terre : ', l




TaillePile=1


!Debut de la cascade

do

if (TaillePile.ne.0) then

!On prend la derniï¿½re particule de la pile
call get_particle(nature,redshift,energie,xx,yy,zz,u,v,w,poids)

write(*,*), TaillePile,redshift,xi
write(*,*),'photon initial en calcul :' , j,'/',nmax

  !Si c'est un photon
  if (nature==0) then

 z0=redshift

 !Variables globales
 redz=z0
 Egamma=energie

!Calcul du redshift pour lequel le photon arriverai dans la zone de detection
!si se dernier m'interagissait pas (on en a besoin pour calculer la profondeur optique)

 call TrouveZlimPhot(z0,zlim,xx,yy,zz,u,v,w,energie,l)

 !Calcul du redshift d'interaction
 !et de l'origine du photon d'interaction (CMB ou EBL, strockee dans var globale DuetoCMB)
 call CalculZintPairprod(zlim,z0,redshift) ! la variable redshift prend la valeur de zint

 !Calcul de la position du photon et energie au moment de l'interaction
 call distancePhoton(z0,redshift,energie,xx,yy,zz,u,v,w)

 redz=redshift
 Egamma=energie

 dist=sqrt(xx**2+yy**2+zz**2)

    if ((.not.vaInteragir).or.dist>l) then ! si la particule n'interagit pas ou si elle a depasse le bord

    !Calcul de sa position et de son energie au niveau de la detection

      call distancePhoton(redshift,zlim,energie,xx,yy,zz,u,v,w)


	!On ecrit dans le fichier
      write(unit=11,fmt=*),nature,zlim,energie,xx,yy,zz,u,v,w,poids
           call register(energie,poids,nature)
    else !sinon on calcule l'interaction

      call mkpairs(energie,u,v,w,redshift,energieE1,uE1,vE1,wE1,energieE2,uE2,vE2,wE2,erreur)

    !On rajoute les deux leptons a la pile
frac=(energieE1/energie)**alphaS
      call store_particle(natureElec,redshift,energieE1,xx,yy,zz,uE1,vE1,wE1,poids)
frac=(energieE2/energie)**alphaS
      call store_particle(naturePosi,redshift,energieE2,xx,yy,zz,uE2,vE2,wE2,poids)


    end if


  else !Si on a un electron ou un positron
  
   Eelec=energie*m*c*c !besoin de dmentionne car CalculZintCompton est programme comme ca
    !(tandis que la PP est programmee avec des quntitees adim)
    !Eelec est une variable globale utilisee dans integranddtaudxCom

   zcoresE=redshift
   z0=redshift

   !On cherche le z lim de detection si pas d'interaction dans le but de calculer la profondeur optique

   call TrouveZlimLep(z0,zlim,xx,yy,zz,u,v,w,energie,l,nature)

   EelecAvant=energie-1. !variable globale pour le calcul de xi pour l'acc Compton

  !Calcul pour savoir a quel redshift aura lieu Compton pour l'electron

  call CalculZintCompton(zlim,z0,redshift)
EelecAvant=energie+1.

  Eelec=Eelec/(m*c*c) !On adimanetionne car les routines suivantes prennent des energies adimentionnes

  !Calcul de la position et energie de l'electron au moment de l'interaction Compton

  call trajectoireLepton(z0,redshift,energie,xx,yy,zz,u,v,w,nature)

  zcoresE=redshift
Eelec=energie*m*c*c


dist=sqrt(xx**2+yy**2+zz**2)

 if ((.not.vaInteragir).or.dist>l) then ! si la particule n'interagit pas ou si elle a depasse le bord
 
 !Calcul de sa position et de son energie au niveau de la detection

 call trajectoireLepton(redshift,zlim,energie,xx,yy,zz,u,v,w,nature)

 ! Ecriture dans le fichier
 write(unit=11,fmt=*),nature,zlim,energie,xx,yy,zz,u,v,w,poids
           call register(energie,poids,nature)
 else

 energie=energie-1. !car les routines de Julien considerent l'energie comme l'energie cinetique pour les leptons

 EelecAvant=energie

 diravU=u
 diravV=v
 diravW=w

  call isophotcompton(energie,u,v,w,energiePhot,uPhot,vPhot,wPhot,redshift)

  !Application accumulation compton sur angles
  sinalpha=sqrt((diravV*w-diravW*v)**2+&
  (diravW*u-diravU*w)**2+&
  (diravU*v-diravV*u)**2)
  sinalpha=max(0._prec,min(1._prec,sinalpha))

  cosalpharxi=cos(asin(sinalpha)*sqrt(xi))

  angle_den=diravU*(u-diravU)+diravV*(v-diravV)+diravW*(w-diravW)
  if (abs(angle_den).gt.tiny(1._prec)) then
  ll=(cosalpharxi-1.)/angle_den

  u=diravU+ll*(u-diravU)
  v=diravV+ll*(v-diravV)
  w=diravW+ll*(w-diravW)
  end if
  call renorme(u,v,w)

  !Application accumulation compton sur energie
  energie=EelecAvant+(energie-EelecAvant)*xi
  energie=energie+1

   if (energie<0.) then

     write(*,*), 'erreur : energie de l electron negative : seuil d accumulation compton trop eleve'
     stop

   end if
  
      !On met a jour la pile
frac=(energie/EelecAvant)**alphaS
      call store_particle(nature,redshift,energie,xx,yy,zz,u,v,w,poids)
frac=(energiePhot/EelecAvant)**alphaS
      call store_particle(naturePhot,redshift,energiePhot,xx,yy,zz,uPhot,vPhot,wPhot,poids*xi)


  end if
  

  end if
end if

 if (TaillePile==0) exit                           ! empty stack

end do

end do
 close (unit=11)
 close (unit=12)
call user_output(nmax)
 write(unit=10,fmt=*), 'Pair production fallback count = ', pairprod_fallback_count
 write(unit=10,fmt=*), 'Pair production norm warning count = ', pairprod_norm_warning_count
 close (unit=10)

call ETIME(tarray, t2)
write (*,*) 'temps ecoule = ', t2-t1

 end program Cascade
 
