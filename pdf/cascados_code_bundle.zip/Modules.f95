!! Module contenant constantes physiques (uniés cgs) et paramètres
module constantes

  implicit none
  !Constantes physiques
    INTEGER, parameter :: prec=selected_real_kind(15, 307)
  real(prec), parameter :: e=4.8032068D-10 
  real(prec), parameter :: m=9.1093897D-28 
  real(prec), parameter :: c=2.99792458D+10  !Unités cgs
  real(prec), parameter :: k=1.380658E-16 
  real(prec), parameter :: h=6.62606957*1.D-27
  real(prec), parameter :: Tcmb=2.725  
   real(prec), parameter :: un=1. 
  real(prec), parameter :: pi=4*atan(un) 
  real(prec), parameter :: alpha=1./137.035999679
  real(prec), parameter :: lanbda=3.86E-11 
  real(prec), parameter :: hb=1.05457266E-27
  real(prec) :: Tcmbp=(k*Tcmb)/(m*c*c) ! Energie thermique adimentionnée
  real(prec), parameter :: r0=e*e/(m*c*c)
  real(prec), parameter :: lanbdaC=hb/(m*c)
  real(prec), parameter :: Mpc=(3.08568025D+16)*1.D+6 ! Un Mpc en metres
  real(prec), parameter :: H0=70*1000/(Mpc) ! H0 en secondes^-1
  real(prec), parameter :: omegaM=0.3
  real(prec), parameter :: omegaK=0.
  real(prec), parameter :: omegaL=0.7
  real(prec), parameter :: a0=1.
  real(prec):: xi=1. ! Pour accumulation compton
  real(prec):: xi1=1. ! Pour accumulation compton CMB
  real(prec):: xi2=1. ! Pour accumulation compton EBL
  real(prec)::  EelecAvant


  logical :: duetoCMB=.true. ! .true. si interaction due au CMB, .false. si EBL
  logical :: vaInteragir=.false. ! savoir s'il y aura interaction (PP ou Com) avant que z=0.

  real(prec) :: z(18), hv(50), nez(50,18),ener(50)
  real(prec), parameter :: sigmaT=8.*pi*(r0**2)/3. !section efficace Thomson
  
  ! Paramètres du programme
  INTEGER, parameter :: ngp=30 !nombre de points pour la méthode de Gauss-Legendre
  real(prec) :: xabsc(ngp), weig(ngp) ! vecteurs contenant positions
                                                       !et poids pour Gauss-Legendre
  integer, parameter :: max_rejection_iter=100000
  real(prec), parameter :: pairprod_eps_upper_floor = 2.402285564062D-5
  real(prec), parameter :: ebl_accum_reference_eps = 1.402285564062D-5
  real(prec), parameter :: compton_eps_min = 1.0D-40
  real(prec), parameter :: compton_eps_max = 2.0D-11

! Parametres EGMF. EGMF_B0_G is a uniform field; zeros preserve the old path.
  logical :: UseEGMF=.true.
  logical :: UseSynchrotron=.false.
  logical :: UseAccComptonForEGMF=.false.
  integer :: B_mode=0 ! 0: B0 is physical G, 1: B0 is comoving G
  real(prec) :: B_floor_G=1.D-40
  real(prec) :: EGMF_phi_max=5.D-2
  real(prec) :: EGMF_B0_G(3)=(/0._prec,0._prec,0._prec/)

!Pour accelerer le programme (attention a ne pas trop abuser)
  real(prec) :: alphaS=0.5d0, frac ! alphaS=1. on garde le moins possible, alphaS=0. : on garde tout le monde
  real(prec)::  SeuilAccCompton=0.d0 !Seuil accumulation Compton


!Nomnre de particules
integer :: TaillePile=0
integer,parameter :: max_particles=100
integer,parameter :: n_bin=81
real(prec) :: spec(n_bin,0:1)=0._prec,grille(n_bin)=0._prec   ! diffuse spectrum
integer :: spec_underflow_count=0
integer :: spec_overflow_count=0
integer :: pairprod_fallback_count=0
integer :: pairprod_norm_warning_count=0

!Declaration d'un type permettant de decrire les particules
    type particule
      integer :: nature ! -1 pour electron, 1 pour positron, 0 pour photon
      real(prec) :: redshift,ener,x,y,z,u,v,w,poids
    end type particule

! Declaration du tableau contenant toutes les articules et leur proprietes
!(taille indeterminee)
  type (particule) act,Par(max_particles)




contains

  real(prec) function planck_inv_occupation(theta)
    implicit none
    real(prec), intent(in) :: theta
    real(prec) :: denom

    if (theta.le.0._prec) then
       write(*,*), 'planck_inv_occupation: theta must be positive', theta
       stop 1
    end if

    if (theta.lt.1.D-2) then
       denom = theta + theta**2/2._prec + theta**3/6._prec + theta**4/24._prec
       planck_inv_occupation = 1._prec/denom
    else
       planck_inv_occupation = 1._prec/(exp(theta)-1._prec)
    end if
  end function planck_inv_occupation

  
end module constantes

module variables
use constantes, only: prec
! Variables globales
  real(prec) :: Egamma ! energie du photon gamma
  real(prec) :: redz ! redshift correspondant
  real(prec) :: Eelec ! energie de l'électron
  real(prec) :: zcoresE ! redshift correspondant
  integer :: iseed=-123456789 ! seed deterministe pour la generation de nombres aleatoires
  
end module variables
