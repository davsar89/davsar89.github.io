close all
clear all
clc

xx=importdata('spec_diff');
EE=xx(:,1);
fraction=xx(:,2);
reference=xx(:,3);

DE=zeros(length(xx),1);
EEE=zeros(length(xx),1);

for j=2:length(xx)
EEE(j)=EE(j-1)+(EE(j)-EE(j-1))/2;
DE(j)=EE(j)-EE(j-1);
end

density=zeros(length(xx),1);
for j=2:length(xx)
if (DE(j)>0)
density(j)=fraction(j)/DE(j);
end
end

loglog(EEE,EEE.*EEE.*density)
hold on
loglog(EE,reference,'g')
