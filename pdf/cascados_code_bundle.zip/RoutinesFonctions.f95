
!------------------------------------------------------------------------------
! Rechercher les indices encadrants une valeur dans un vecteur
!------------------------------------------------------------------------------
subroutine r8vec_bracket ( n, x, xval, left, right )

!*****************************************************************************80
!
!! R8VEC_BRACKET searches a sorted R8VEC for successive brackets of a value.
!
!  Discussion:
!
!    An R8VEC is an array of double precision real values.
!
!    If the values in the vector are thought of as defining intervals
!    on the real line, then this routine searches for the interval
!    nearest to or containing the given value.
!
!  Licensing:
!
!    This code is distributed under the GNU LGPL license.
!
!  Modified:
!
!    06 April 1999
!
!  Author:
!
!    John Burkardt
!
!  Parameters:
!
!    Input, integer ( kind = 4 ) N, length of input array.
!
!    Input, real ( kind = 8 ) X(N), an array sorted into ascending order.
!
!    Input, real ( kind = 8 ) XVAL, a value to be bracketed.
!
!    Output, integer ( kind = 4 ) LEFT, RIGHT, the results of the search.
!    Either:
!      XVAL < X(1), when LEFT = 1, RIGHT = 2;
!      X(N) < XVAL, when LEFT = N-1, RIGHT = N;
!    or
!      X(LEFT) <= XVAL <= X(RIGHT).
!

use constantes, only : prec
  implicit none

  integer ( kind = 4 ) n

  integer ( kind = 4 ) i
  integer ( kind = 4 ) left
  integer ( kind = 4 ) right
  real ( kind = prec ) x(n)
  real ( kind = prec) xval

  do i = 2, n - 1

    if ( xval < x(i) ) then
      left = i - 1
      right = i
      return
    end if

   end do

  left = n - 1
  right = n

  return
end


!..............................................................................
!          random number generator from Numerical Recipes (Fortran90)         .
!..............................................................................
function ran0()
  use constantes, only : prec
  use variables, only : iseed
  implicit none
  real(prec) :: ran0
  integer,parameter :: IA=16807,IM=2147483647,IQ=127773,IR=2836
  real(prec), save :: am
  integer, save :: ix=-1, iy=-1,k

  if (iseed <= 0 .or. iy < 0) then
     am = nearest(1._prec,-1._prec)/real(IM,prec)
     iy = ior(ieor(888889999,abs(iseed)),1)
     ix = ieor(777755555,abs(iseed))
     iseed = abs(iseed)+1
  end if
  ix = ieor(ix,ishft(ix,13))
  ix = ieor(ix,ishft(ix,-17))
  ix = ieor(ix,ishft(ix,5))
  k = iy/IQ
  iy = IA*(iy-k*IQ)-IR*k
  if (iy<0) iy = iy+IM
  ran0 = am*ior(iand(IM,ieor(ix,iy)),1)
  end function ran0


!------------------------------------------------------------------------------
!Intrégaration par méthode de Gauss : calcul des poids et des abscisses
!------------------------------------------------------------------------------
!********************************************************************************
!* Calculation of GAUSS-LEGENDRE abscissas and weights for Gaussian Quadrature
!* integration of polynomial functions.
!*      For normalized lower and upper limits of integration -1.0 & 1.0, and
!* given n, this routine calculates, arrays xabsc(1:n) and  weig(1:n) of length n,
!* containing the abscissas and weights of the Gauss-Legendre n-point quadrature
!* formula.  For detailed explanations finding weights & abscissas, see
!* "Numerical Recipes in Fortran */
!********************************************************************************
  SUBROUTINE  gauleg(ngp, xabsc, weig)
      use constantes, only : prec,pi
  implicit none
  INTEGER  i, j, m
  real(prec)  p1, p2, p3, pp, z, z1
  INTEGER, INTENT(IN) :: ngp            ! # of Gauss Points
  real(prec), INTENT(OUT) :: xabsc(ngp), weig(ngp)
  real(prec)  :: eps
  PARAMETER (eps=3.0d-15)        !EPS is the relative precision


  m = (ngp + 1) / 2
!* Roots are symmetric in the interval - so only need to find half of them  */

  do i = 1, m    ! Loop over the desired roots */

  z = cos( pi * (i-0.25) / (ngp+0.5) )
!*   Starting with the above approximation to the ith root,
!*          we enter the main loop of refinement by NEWTON'S method   */
100  p1 = 1.0
  p2 = 0.0
!*  Loop up the recurrence relation to get the Legendre
!*  polynomial evaluated at z                 */

  do j = 1, ngp
  p3 = p2
  p2 = p1
  p1 = ((2.0*j-1.0) * z * p2 - (j-1.0)*p3) / j
  enddo

!* p1 is now the desired Legendre polynomial. We next compute pp,
!* its derivative, by a standard relation involving also p2, the
!* polynomial of one lower order.      */
  pp = ngp*(z*p1-p2)/(z*z-1.0)
  z1 = z
  z = z1 - p1/pp             ! Newton's Method  */

  if (abs(z-z1) .gt. EPS) GOTO  100

  xabsc(i) =  - z                     ! Roots will be bewteen -1.0 & 1.0 */
  xabsc(ngp+1-i) =  + z                 ! and symmetric about the origin  */
  weig(i) = 2.0/((1.0-z*z)*pp*pp) ! Compute the weight and its       */
  weig(ngp+1-i) = weig(i)               ! symmetric counterpart         */

  end do     ! i loop

  End subroutine gauleg


!------------------------------------------------------------------------------
!Intrégaration par méthode de Gauss : calcul de l'intégrale
!------------------------------------------------------------------------------
!********************************************************************************
!*     Returns the SINGLE integral of the function (of ONE VARIABLE) "func"
!* between x1 and x2 by N-point Gauss-Legendre integration. The function
!* is evaluated exactly N times at interior points in the range of
!* integration.       */
!********************************************************************************
  recursive function qgauss(func, x1, x2) RESULT(intgrl)
      
 ! Modules utilisés
  USE constantes
  USE variables
  implicit none
 
  real(prec)  intgrl, x1, x2, func
  real(prec)  xm, xl
  INTEGER j


if (x1==x2) then
intgrl=0.
else

  intgrl = 0.0
  xm = 0.5 * (x2 + x1)
  xl = 0.5 * (x2 - x1)
 
  do j = 1, ngp
  intgrl = intgrl + weig(j) * func( xm + xl*xabsc(j))
  END do
  
  intgrl = intgrl * xl;    !Scale the answer to the range of integration  */
end if
  END function qgauss


!------------------------------------------------------------------------------
!Intrégaration par méthode de Gauss : calcul de l'intégrale en passant le redshift en argument
!------------------------------------------------------------------------------
!********************************************************************************
!*     Returns the SINGLE integral of the function (of ONE VARIABLE) "func"
!* between x1 and x2 by N-point Gauss-Legendre integration. The function
!* is evaluated exactly N times at interior points in the range of
!* integration.       */
!VERSION utilisée pour l'intégration sur z car il faut passer redzz en argument
!********************************************************************************
  recursive function qgaussZ(func, x1, x2, redzz) RESULT(intgrl)
      
  ! Modules utilisés
  USE constantes
  USE variables
  implicit none
 
  real(prec)  intgrl, x1, x2, func
  real(prec)  xm, xl, redzz
  INTEGER j


  
  if (x1==x2) then
intgrl=0.
else

  intgrl = 0.0
  xm = 0.5 * (x2 + x1)
  xl = 0.5 * (x2 - x1)
 
  do j = 1, ngp
  intgrl = intgrl + weig(j) * func( xm + xl*xabsc(j), redzz)
  END do

  intgrl = intgrl * xl;    !Scale the answer to the range of integration  */
  
end if

  END function qgaussZ


  recursive function qgaussDr(func, x1, x2, z1,gamma1) RESULT(intgrl)
      
 ! Modules utilisés
  USE constantes
  USE variables
  implicit none
 
  real(prec)  intgrl, x1, x2, func
  real(prec)  xm, xl,z1,gamma1
  INTEGER j


  intgrl = 0.0
  xm = 0.5 * (x2 + x1)
  xl = 0.5 * (x2 - x1)
 
  do j = 1, ngp
  intgrl = intgrl + weig(j) * func( xm + xl*xabsc(j), z1,gamma1)
  END do

  intgrl = intgrl * xl;    !Scale the answer to the range of integration  */
   END function qgaussDr


!------------------------------------------------------------------------------
! Lecture fichier Dominguez et al.
!------------------------------------------------------------------------------
SUBROUTINE  EBLLecture()
USE constantes
IMPLICIT none

real(prec) ::  lambda (50), hvv(50),nezz(50,18)
real(prec) :: mat(50,19) ! la matrice mat contient lambda sur sa première colonne et les valeurs du CIB à différents redshifts dans les autres
Integer :: i, j, ios


! On lit (une seule fois, à cause du flag) les lambda et les valeurs de EBL

  ! On lit le redshifts
  !chaque colonne fichier contient le Lamda*I_lambda de Dominguez et al.
  ! sauf la première qui contient les lambda
  open(UNIT=60,file="z_EBL",status="old",action="read",iostat=ios)
  if (ios.ne.0) then
     write(*,*), 'EBLLecture: cannot open z_EBL for reading, iostat=', ios
     stop 1
  end if
do i=1,size(z)
    read(60,*,iostat=ios) z(i)
    if (ios.ne.0) then
       write(*,*), 'EBLLecture: failed reading z_EBL row', i, 'iostat=', ios
       stop 1
    end if
end do
  close(UNiT=60)
   
  ! On lit et converti l'EBL
 
  open(UNIT=61,file="EBL",status="old",action="read",iostat=ios)
  if (ios.ne.0) then
     write(*,*), 'EBLLecture: cannot open EBL for reading, iostat=', ios
     stop 1
  end if
  ! lectures donnees Dominguez et al. et strockage dans la matrice mat
  Do i=1,size(mat,1)
  read(61,*,iostat=ios) mat(i,1), mat(i,2), mat(i,3), mat(i,4), mat(i,5), mat(i,6), mat(i,7), mat(i,8), mat(i,9), &
  mat(i,10), mat(i,11), mat(i,12), mat(i,13), mat(i,14), mat(i,15), mat(i,16), mat(i,17), mat(i,18), mat(i,19)
  if (ios.ne.0) then
     write(*,*), 'EBLLecture: failed reading EBL row', i, 'expected 19 columns, iostat=', ios
     stop 1
  end if
   
  ! Convertion de lambda en energie et de mat en photon par cm^3 et par energie
  lambda(i)=mat(i,1)
  hv(i)=h*c/(lambda(i)*1.D-4)
  ener(i)=hv(i)/(m*c*c)

  do j=2,size(mat,2)
  ! conversion en photon par volume et par energie
  nez(i,j-1)=(1.D+7)     *    (1.D-9)     *  (1.D-4) *    4*pi*mat(i,j)/((hv(i)**2)*(c))

  ! J en erg        nW en W    !/m^2 à /cm^2
  end do
  end do
  
  !On inverse l'ordre pour avoir hv croissant pour pouvoir faire l'interpolation
  Do i=1,size(nez,1)
  hvv(i)=hv(size(nez,1)-i+1)
  nezz(i,:)=nez(size(nez,1)-i+1,:)
  end DO
  
  hv=hvv
  ener=hvv/(m*c*c) ! energie adimentionnée
  nez=nezz
  
  ! Adimentionalisation de de la densité de photons n(e,z)
  
  nez=nez/(((hb*c)**(-3))*(((m*c*c))**2))

 close(UNiT=61)
 

end subroutine EBLLecture
   
!------------------------------------------------------------------------------ 
!interpoler les fichiers tabulés de Dominguez et al. pour avoir la densite de l'EBL
!------------------------------------------------------------------------------
SUBROUTINE  NeInterpol(epss,redddz, EBLinterpol)
USE constantes
IMPLICIT none



real(prec) :: fx, fy
real(prec), INTENT(IN) :: epss, redddz !variables de l'énergie des photons et du redshift
real(prec), INTENT(OUT) :: EBLinterpol ! Valeurs de lambda*I_lambda de l'EBL intepolées sur le fichier de Dominguez et al.
Integer ::  leftE, rightE, leftZ, rightZ



EBLinterpol=0. 


!recherche des (leftE,rightE) et (leftZ,rightZ) qui encadrent les valeurs de epss et reddz demandées
CAll r8vec_bracket(size(ener), ener, epss, leftE, rightE )
CAll r8vec_bracket(size(z), z, redddz, leftZ, rightZ )


!Si le point est hors grille des données, on met n=0
if (epss>maxval(ener) .OR. epss<minval(ener) .OR. redddz<minval(z) .OR. redddz>maxval(z)) then
  EBLinterpol=0. 
else


   

  fx=(epss-ener(leftE))/(ener(rightE)-ener(leftE))
  fy=(redddz-z(leftZ))/(z(rightZ)-z(leftZ))

   
  EBLinterpol=(1.-fx)*(1.-fy)*nez(leftE,leftZ)+&
  (1.-fx)*fy*nez(leftE,rightZ)+&
  fx*(1.-fy)*nez(rightE,leftZ)+&
  fx*fy*nez(rightE,rightZ)


 
end if

EBLinterpol=((1.+redddz)**3)*EBLinterpol !compensation du 10^40 précédent 
       !et application redshift.



end  SUBROUTINE NeInterpol 
 

!------------------------------------------------------------------------------ 
! Tirer un photon sur CMB
!------------------------------------------------------------------------------
  subroutine selecphot(ee,zint)
   USE constantes
      implicit none
      real(prec):: cc,d,a1,a2,a3,a4,ee,ran0,zeta,zint
      integer:: mm

            a2=ran0()
            a3=ran0()
            a4=ran0()
            d=a2*a3*a4

         a1=ran0()
         a1=1.202*a1
         mm=1
         zeta=1
         do while (a1.ge.zeta)
            mm=mm+1
            cc=mm
            zeta=zeta+1/cc**3
         enddo
         cc=mm
         ee=-Tcmbp*(1.+zint)/cc*log(d)
  
      end  SUBROUTINE selecphot 


!------------------------------------------------------------------------------
! Tirer un photon sur CMB coupé aux basses énergies
!------------------------------------------------------------------------------
 subroutine genx(ee,emin,zint)
!    e,emin,kt in mec^2 units   
   USE constantes
      implicit none
      real(prec):: x=0.,x0,ran0,a1,g
      real(prec):: dx1,dx00,b,dx0,ee,emin
      real(prec):: ktr,xt,yt,deps,zint
      integer :: iter, iter_newton

 ktr=Tcmbp*(1.+zint)

      x0=emin/ktr
      xt=1.
      yt=0.
      iter=0
      do while(xt.gt.yt)
      iter=iter+1
      if (iter.gt.max_rejection_iter) then
         write(*,*), 'genx: rejection loop did not converge', emin, zint, x0
         stop 1
      end if
      a1=ran0()
      dx00=-log(a1)
      dx0=0.
      dx1=dx00
      b=1+X0+x0*x0/2.
      deps=1d-6
      iter_newton=0
      do while (abs((dx1-dx0))/dx1.gt.deps)
      iter_newton=iter_newton+1
      if (iter_newton.gt.max_rejection_iter) then
         write(*,*), 'genx: Newton loop did not converge', emin, zint, x0
         stop 1
      end if
      dx0=dx1
      x=x0+dx0
      g=(1.+x+x*x/2.)/b
      dx1=dx00+log(g)
      enddo
      yt=(1.-exp(-x0))/(1.-exp(-x))
      xt=ran0()
      enddo
      ee=x*ktr
      end subroutine genx
!------------------------------------------------------------------------------     
! Tirer un vecteur (u,v,w) de manière isotrope
!------------------------------------------------------------------------------
subroutine isotrop(u,v,w)
   USE constantes
         implicit none
      real(prec):: u,v,w,a1,a2,ran0
      a1=ran0()
      a2=ran0()
      w=a1*2.-1.
      u=sqrt(1-w*w)*cos(2*pi*a2)
      v=sqrt(1.-w*w)*sin(2.*pi*a2)
      end subroutine isotrop


!------------------------------------------------------------------------------
! Tirer un photon de l'EBL
!------------------------------------------------------------------------------
subroutine selecPhotEBL(ee,zint)
   USE constantes
         implicit none
   EXTERNAL NeInterpol 
   
      real(prec) :: a1,a2,ran0,Ne,ee,NN,zint,reject
      real(prec) :: minener,maxener,maxEBL
      real(prec) :: nEBL_at_z(size(ener))
      integer :: i, iter

reject=1.

!On interpole un vecteur de valeurs de l'EBL pour un redshift donné
minener=minval(ener)
maxener=maxval(ener)
if (minener.le.0._prec.or.maxener.le.minener) then
   write(*,*), 'selecPhotEBL: invalid EBL energy bounds', minener, maxener
   stop 1
end if

do i=1,size(ener)
   call NeInterpol(ener(i), zint, nEBL_at_z(i))
end do
maxEBL=maxval(ener*nEBL_at_z)
if (maxEBL.le.0._prec) then
   write(*,*), 'selecPhotEBL: zero EBL envelope', zint, minener, maxener
   stop 1
end if

! Rejection sur les valeurs tabulées de l'EBL

iter=0
Do while (reject>0.5)
      iter=iter+1
      if (iter.gt.max_rejection_iter) then
         write(*,*), 'selecPhotEBL: rejection loop did not converge', zint, maxEBL
         stop 1
      end if
 a1=ran0()
      a2=ran0()
      
      ee=log(minener)+a1*(log(maxener)-log(minener))
      

      
      NN=a2*(maxEBL)

!write(*,*),exp(ee),exp(NN)*fact,minener,maxener,minEBL*fact,maxEBL*fact

      Call NeInterpol(exp(ee),zint,Ne)
      
     !write(*,*), exp(ee)
      
     ! write(*,*), exp(ee)*1.D-10*Ne,NN
      !write(*,*), maxval(enerr),minval(enerr),fact*maxval(nezzz),fact*minval(nezzz),fact*Ne
      
      if (NN<Ne*exp(ee)) then
      
      reject=0.1

      end if

      if (Ne<=0._prec) then ! si jamais on a débordé des valeurs tabulées, la rejection n'est pas bonne
      !write(*,*), Ne
      reject=1.
      
      end if
      
      ee=exp(ee)
 
end do

      end subroutine selecPhotEBL
      
!-----------------------------------------------------------------------------------------------
! Calcule les produits de la création de paire à partir des caractéristiques du photon incident  
!-----------------------------------------------------------------------------------------------  
  subroutine mkpairs(Egama,ul,vl,wl,zint,ep1,u1,v1,w1,ep2,u2,v2,w2,erreur)
      use constantes
      implicit none
      integer it
      real(prec) :: ktr
     real(prec) ::Egama,zint
      real(prec) ::ep1,u1,v1,w1
      real(prec) :: ep2,u2,v2,w2
      real(prec) :: ran0
      real(prec) :: ut=0.,vt=0.,wt=0.,eminmin
      real(prec) :: gama,betaca,beta,coef,mu
      real(prec) :: uu(2),vv(2),ww(2)
      real(prec) :: emin
      real(prec) :: ul,vl,wl,xt,yt
      real(prec) :: hnu1,hnu2,delta=0.
      logical rejec,erreur
ktr=Tcmbp*(1.+zint)
! input: e,...: energy,direction position of incident photon + redshift of interaction

! output:
! energy position durection of the second incident photon (from EBL or CMB)
! ep1, ...: energy, direction of produced lepton 1
! ep2, ...:  energy, direction of produced lepton 2
! erreur:  this becomes .true. when some weird stuff happens




!     on calcule gama : le facteur de lorentz dans le CM
!     des electrons crees
!     on teste le seuil de la 
!     reaction (gama >1)   
      erreur=.false.
      hnu1=Egama
      hnu2=0.
      emin=1.

!c calculates ul,vl,wl, photon coordinates in a base eu,ev,ew
! such that ew=er, and the photon direction is in the plane (eu, ew) and perpendicular to ev
! note that cospsy here is of oposite sign to the cospsy of Dubus (2006) A.8

      rejec=.true.
      it=0

!  evaluate trheshold
         eminmin=1./Egama
      



!    select target photon
      do while(rejec)
         it=it+1
         if (it.gt.max_rejection_iter) then
            write(*,*), 'mkpairs: rejection loop did not converge', Egama, zint, emin, hnu2
            stop 1
         end if

! A failed cross-section rejection rejects the whole target candidate.
         hnu2=0._prec
         emin=1._prec
         delta=0._prec
         ut=0._prec
         vt=0._prec
         wt=0._prec

!    select energy according to BB distribution
         Do while(hnu2.lt.emin)
         it=it+1
         if (it.gt.max_rejection_iter) then
            write(*,*), 'mkpairs: target photon loop did not converge', Egama, zint, emin, hnu2
            stop 1
         end if
          
if (duetoCMB) then ! si la production de paire est du au CMB

            if (eminmin/ktr.lt.1.) THEN


! low threshold photon energy drawn over CMB
         call selecphot(hnu2,zint)
  else
         call genx(hnu2,eminmin,zint)
!! BB truncated at low energy (to check)
            endif
else  ! si le production de paire est due à l'EBL
  call selecphotEBL(hnu2,zint)

end if



!  select angle according to isotrpic distribution
               call isotrop(ut,vt,wt)
               delta=1.-ul*ut-vl*vt-wl*wt

 
!      computre threshold energy for the interaction
            if (delta.le.tiny(1._prec)) cycle
            emin=2./Egama/delta

             
         enddo
! here we have a candidate target photon drawn from isotropic blackbody distribution
! and energy compatible with pp threshold
!  we have to decide whether we keep it or not. 
! we do that with a rejection test on the amplitude of the cross section

         mu=1.-delta
! mu=cos angle between photons          
         gama=hnu1*hnu2*(1.-mu)/2.
!  lorentz factor of created leptons in their CM frame.

         IF (gama.lt.1.)  write(6,*) 'ERREUR GAMMA^2<1'
                  
         IF (erreur) THEN 
            rejec=.false.
         ELSE
!   calcule la section efficace reelle et test de rejection
            xt=ran0()
            gama=sqrt(gama)
            betaca=1-gama**(-2)
            beta=sqrt(betaca)
            coef=1.-mu
            
            yt=(3.-betaca**2)*log((1+beta)/(1-beta))
            yt=yt-2.*beta*(2.-betaca)
            yt=yt*(1-betaca)*coef/(1.36341*2.)

            
            if (xt.lt.yt) then
!   target photon selected, proceed to simulate interaction                                   
               uu(1)=ul
               vv(1)=vl
               ww(1)=wl
               uu(2)=ut
               vv(2)=vt
               ww(2)=wt      
               
               call pair_production(hnu1,hnu2,uu,vv,&
                   ww,mu,gama,betaca,beta)
               
               ep1=hnu1-1.
               ep2=hnu2-1.

!     keep electrons diretion
                  u1=uu(1)
                  u2=uu(2)
                  v1=vv(1)
                  v2=vv(2)
                  w1=ww(1)
                  w2=ww(2)

!write(*,*), u1,u2,v1,v2,w1,w2
               rejec=.false.
            endif
         endif     
      enddo
      end subroutine

!------------------------------------------------------------------------------
!Calcul proprietes production de paire      
!------------------------------------------------------------------------------ 
      subroutine pair_production(hnu1,hnu2,uu,vv,ww,up1up2,&
      gama,betaca,beta)
!------------------------------------------------------------------------------
      use constantes
      IMPLICIT NONE
!     hnu1 et hnu2 en unite mc^2 (m masse electron)
      
      real(prec) :: hnu1,hnu2,up1,vp1,vp2,wp1,wp2,gama1
      real(prec) :: gama,beta,gambeta,betacm,gamacm
      real(prec) :: uu(2),vv(2),ww(2)
      real(prec) :: gambetacm,a=0.,ucmup1,up1up2,up2,a1,a2,a3,b1,b2,b3,c1,c2,c3
      real(prec) :: al,ymax,y1,u,yt,x,y,zz,ran0,ap,am,phi,a11
      real(prec) :: mu,ucmu1cm,ucm=0.,vcm=0.,wcm=0.,u1cm,v1cm,w1cm,shnu
      real(prec) :: y2,betaca,gama2,rad1,rad2,norm1,norm2
      real(prec) :: u1,v1,w1,u2,v2,w2
      integer :: iter
      logical ech
      
      
      up1=uu(1)
      up2=uu(2)
      vp1=vv(1)
      vp2=vv(2)
      wp1=ww(1)
      wp2=ww(2)
      
!     gama,beta :energie des electrons dans le referentiel CM
!     gamacm,betacm, ucm,vcm,wcm :parametres du referentiel du CM
      
      
      shnu=hnu1+hnu2
      
      gamacm=.5*shnu/gama
      betacm=sqrt(1.-gamacm**(-2.))
      gambetacm=gamacm*betacm
      gambeta=gama*beta
      
      
!     TIRAGE DE LA DIRECTION DE L ELECTRON 1 DANS CM
      
      y1=1+2.*betaca*(1-betaca)
      y2=2.*(betaca-1.)**2-1.
      yt=1.
      y=0.
!     ymax=y1
!    alpha=sqrt(1-1/rac2)
      
!    IF (beta.gt.alpha) THEN
      
!     u=(1-rac2)+rac2*betaca
!    ymax=ymax-(y2*u+u**2)/(1.-u)
 
!     ENDIF
      ymax=2.
      iter=0
      
      DO WHILE (yt.gt.y)
         iter=iter+1
         if (iter.gt.max_rejection_iter) then
            write(*,*), 'pair_production: direction rejection did not converge', gama, beta
            stop 1
         end if
         
         x=2.*ran0()-1.
         ap=(1+beta)**x
         am=(1-beta)**x

         x=(ap-am)/(ap+am)
         u=x**2
         y=y1-(y2*u+u**2)/(1.-u)
         yt=ymax*ran0()
         
      ENDDO
      
      mu=x/beta
      phi=2.*pi*ran0()
      y1=(1-mu**2)**.5
      y=cos(phi)*y1
      zz=sin(phi)*y1
        

 
!      CALCUL DE LA MATRICE DE CHANGEMENT DE BASE
      
      IF (betacm.gt.1d-10) THEN

         a=shnu*betacm
         a1=hnu1/a
         a2=hnu2/a
         
         ucm=a1*up1+a2*up2
         vcm=a1*vp1+a2*vp2
         wcm=a1*wp1+a2*wp2
         
         ucmup1=a1+a2*up1up2

         
         a11=hnu1*(-gambetacm+(gamacm-1.)*ucmup1)/gama
         a2=hnu1/gama
         
      ELSE 
         
         a11=0.
         a2=1.

      ENDIF
      
!     a1,b1,c1 :direction du photon 1 (up1cm) dans le ref. CM
      
      a1=a11*ucm+a2*up1
      b1=a11*vcm+a2*vp1
      c1=a11*wcm+a2*wp1
        
      IF (abs(a1).lt.7.d-1) THEN
         
!    a2,b2,c2 : vecteur du plan (up1cm,i) normal a up1cm
         
         a2=(1-a1**2)**.5
         al=-a1/a2 
         b2=al*b1
         c2=al*c1
         
      ELSE
         
!    a2,b2,c2 : vecteur du plan (up1cm,j) normal a up1cm
         
         b2=sqrt(1-b1**2)
         al=-b1/b2
         a2=al*a1
         c2=al*c1
         
      ENDIF
      
!     a3,b3,c3 : produit vetoriel des deux precedents (triedre direct) 
      
      a3=b1*c2-c1*b2
      b3=c1*a2-c2*a1
      c3=a1*b2-b1*a2
      
      
!     u1cm,v1cm,w1cm : coordonnees direction electron 1 dans CM dans la base globale (i,j,k)
      
      u1cm=mu*a1+y*a2+zz*a3
      v1cm=mu*b1+y*b2+zz*b3
      w1cm=mu*c1+y*c2+zz*c3
      
!     RETOUR AU REFERENTIEL DU LABO
      
!     calcul de gama1,gama2, energie des electrons cree dans le ref labo
      
      ucmu1cm=ucm*u1cm+vcm*v1cm+wcm*w1cm
      
      y=shnu/2.
      zz=a*beta*ucmu1cm/2.
      
      gama1=y+zz
      gama2=y-zz
               
      a1=gambetacm*gama
      b1=gambeta*(gamacm-1)*ucmu1cm
      c1=gambeta
      rad1=gama1**2-1._prec
      rad2=gama2**2-1._prec
      IF (rad1.gt.0._prec.and.rad2.gt.0._prec) THEN
         a3=sqrt(rad1)
         b3=sqrt(rad2)
         u1=((a1+b1)*ucm+c1*u1cm)/a3       
         v1=((a1+b1)*vcm+c1*v1cm)/a3
         w1=((a1+b1)*wcm+c1*w1cm)/a3
         norm1=sqrt(u1**2+v1**2+w1**2)
         ech=.false.
         ech=abs(norm1-1._prec).gt.1d-5
         if (ech) then
            pairprod_norm_warning_count=pairprod_norm_warning_count+1
            
            write(6,*) 'erreur pair prod  2'
            
            write(6,*) u1
            write(6,*) v1
            write(6,*) w1
            write(6,*) norm1
         endif
         
         u2=((a1-b1)*ucm-c1*u1cm)/b3       
         v2=((a1-b1)*vcm-c1*v1cm)/b3
         w2=((a1-b1)*wcm-c1*w1cm)/b3
         
         norm2=sqrt(u2**2+v2**2+w2**2)
         ech=.false.
         ech=abs(norm2-1._prec).gt.1d-5
         if (ech) then
            pairprod_norm_warning_count=pairprod_norm_warning_count+1
            
            write(6,*) 'erreur anil  2'
            
            write(6,*) u2
            write(6,*) v2
            write(6,*) w2
            write(6,*) norm2
         endif
      ELSE
         pairprod_fallback_count=pairprod_fallback_count+1
         write(6,*) 'Erreur pair_production'
!     no momentum conservation !!!!!!!
         call isotrop(u1,v1,w1)
         call isotrop(u2,v2,w2)
      ENDIF
      
      IF (gama1.ge.gama2) THEN
         hnu1=gama1          
         hnu2=gama2
         uu(1)=u1
         vv(1)=v1
         ww(1)=w1
         uu(2)=u2
         vv(2)=v2
         ww(2)=w2
         
      ELSE
         hnu1=gama2
         hnu2=gama1
         uu(1)=u2
         vv(1)=v2
         ww(1)=w2
         uu(2)=u1
         vv(2)=v1
         ww(2)=w1
      ENDIF
!write(*,*), u1,u2,v1,v2,w1,w2
      END subroutine pair_production


!------------------------------------------------------------------------------  
!Calcul position et energie d'un photon a partir de sa position et de son energie initiale  
!------------------------------------------------------------------------------
  subroutine distancePhoton(zini,zfinal,ephot,x0,y0,zz0,u,v,w)

use constantes, only : c, H0, a0,prec,OmegaM,OmegaL

  implicit none


  real(prec), INTENT(IN) :: zini,zfinal,u,v,w
  real(prec), INTENT(INOUT) :: x0,y0,zz0,ephot
  real(prec) :: deltaR
  real(prec) :: integrandR,qgauss
  external integrandR, qgauss
 

if (abs(zini-zfinal)<1.d-8) then

deltaR=abs(zini-zfinal)*(c/(a0*H0))*(1./(sqrt((omegaM*((1.+zini)**3)+omegaL))))
else

deltaR=(c/(H0*a0))*qgauss(integrandR,zfinal,zini) !Distance parcourue

end if
deltaR=deltaR
x0=(u*deltaR+x0)
y0=(v*deltaR+y0)
zz0=(w*deltaR+zz0)
ephot=ephot*(1.+zfinal)/(1.+zini)



  end subroutine distancePhoton



!-----------------------------------------------------------------------------------------
!Calcul position et energie d'un lepton a partir de sa position et de son energie initiale
!-----------------------------------------------------------------------------------------
  subroutine trajectoireLepton(zini,zfinal,eps,x0,y0,zz0,u,v,w,nature)

 use constantes, only : c,OmegaM,OmegaL,H0,a0,prec,UseEGMF,UseSynchrotron,EGMF_B0_G,B_floor_G

  implicit none

  real(prec), INTENT(IN) :: zini,zfinal
  integer, INTENT(IN) :: nature
  real(prec), INTENT(INOUT) :: eps,x0,y0,zz0,u,v,w
  real(prec) :: Dr,integrandDr,qgaussDr,Bnorm0
 external qgaussDr,integrandDr
!------------------------------------------------------------------------------

Bnorm0=sqrt(dot_product(EGMF_B0_G,EGMF_B0_G))
if (UseEGMF.and.Bnorm0.gt.B_floor_G) then
   if (UseSynchrotron) then
      write(*,*), 'trajectoireLepton: synchrotron losses are not implemented'
      stop 1
   end if
   call propagate_lepton_egmf(zini,zfinal,eps,x0,y0,zz0,u,v,w,nature)
   return
end if

if (abs(zini-zfinal)<1.d-8) then

Dr=abs(zini-zfinal)*(c/(a0*H0))*sqrt(max(0._prec,(1.-1./(1.+((1.+zini)/(1+zini))**2*(eps**2-1))))&
/(OmegaM*(1+zini)**3+OmegaL))

else

Dr=-c/(a0*H0)*qgaussDr(integrandDr,zini,zfinal, zini,eps)


end if
Dr=Dr
x0=u*Dr+x0
y0=v*Dr+y0
zz0=w*Dr+zz0

eps=sqrt(1.+(eps**2-1.)*((1.+zfinal)/(1.+zini))**2)

  end subroutine trajectoireLepton

!------------------------------------------------------------------------------
! Propagation EGMF vectorielle, selon Calculs_EGMF_propagation3D.pdf.
!------------------------------------------------------------------------------
real(prec) function ez_lcdm_egmf(zred)
  use constantes, only : prec,omegaM,omegaK,omegaL
  implicit none
  real(prec), intent(in) :: zred

  ez_lcdm_egmf=sqrt(omegaM*(1._prec+zred)**3+omegaK*(1._prec+zred)**2+omegaL)
end function ez_lcdm_egmf

real(prec) function gamma_no_synch(gamma_i,zred,z_i)
  use constantes, only : prec
  implicit none
  real(prec), intent(in) :: gamma_i,zred,z_i
  real(prec) :: scale,ui2

  scale=(1._prec+zred)/(1._prec+z_i)
  ui2=max(gamma_i*gamma_i-1._prec,0._prec)
  gamma_no_synch=sqrt(1._prec+ui2*scale*scale)
end function gamma_no_synch

subroutine normalize3(vec,vechat,vecnorm)
  use constantes, only : prec
  implicit none
  real(prec), intent(in) :: vec(3)
  real(prec), intent(out) :: vechat(3),vecnorm

  vecnorm=sqrt(dot_product(vec,vec))
  if (vecnorm.gt.0._prec) then
     vechat=vec/vecnorm
  else
     vechat=0._prec
  end if
end subroutine normalize3

subroutine rotate_rodrigues(vec,bhat,phi,vecrot)
  use constantes, only : prec
  implicit none
  real(prec), intent(in) :: vec(3),bhat(3),phi
  real(prec), intent(out) :: vecrot(3)
  real(prec) :: cph,sph,bdotv,bxv(3)

  cph=cos(phi)
  sph=sin(phi)
  bdotv=dot_product(bhat,vec)
  bxv(1)=bhat(2)*vec(3)-bhat(3)*vec(2)
  bxv(2)=bhat(3)*vec(1)-bhat(1)*vec(3)
  bxv(3)=bhat(1)*vec(2)-bhat(2)*vec(1)
  vecrot=vec*cph+bxv*sph+bhat*bdotv*(1._prec-cph)
end subroutine rotate_rodrigues

subroutine EGMF_Bphys(x_comov,zred,Bphys)
  use constantes, only : prec,EGMF_B0_G,B_mode
  implicit none
  real(prec), intent(in) :: x_comov(3),zred
  real(prec), intent(out) :: Bphys(3)
  real(prec) :: Braw(3)

  Braw=EGMF_B0_G+0._prec*x_comov
  if (B_mode.eq.0) then
     Bphys=Braw
  else if (B_mode.eq.1) then
     Bphys=Braw*(1._prec+zred)**2
  else
     write(*,*), 'EGMF_Bphys: unknown B_mode', B_mode
     stop 1
  end if
end subroutine EGMF_Bphys

real(prec) function egmf_bnorm_cell_at_z(Bnorm_i,zred,z_i)
  use constantes, only : prec,B_mode
  implicit none
  real(prec), intent(in) :: Bnorm_i,zred,z_i

  if (B_mode.eq.0) then
     egmf_bnorm_cell_at_z=Bnorm_i
  else if (B_mode.eq.1) then
     egmf_bnorm_cell_at_z=Bnorm_i*((1._prec+zred)/(1._prec+z_i))**2
  else
     write(*,*), 'egmf_bnorm_cell_at_z: unknown B_mode', B_mode
     stop 1
  end if
end function egmf_bnorm_cell_at_z

real(prec) function egmf_phi_between(z_i,z_target,gamma_i,Bnorm_i,charge_sign)
  use constantes, only : prec,e,m,c,H0,ngp,xabsc,weig
  implicit none
  real(prec), intent(in) :: z_i,z_target,gamma_i,Bnorm_i
  integer, intent(in) :: charge_sign
  real(prec) :: zh,zm,zj,integ,gamma_z,Ez_z,Bnorm_z
  real(prec) :: gamma_no_synch,ez_lcdm_egmf,egmf_bnorm_cell_at_z
  integer :: j

  if (abs(z_i-z_target).le.tiny(1._prec)) then
     egmf_phi_between=0._prec
     return
  end if

  zh=0.5_prec*(z_i-z_target)
  zm=0.5_prec*(z_i+z_target)
  integ=0._prec
  do j=1,ngp
     zj=zm+zh*xabsc(j)
     gamma_z=gamma_no_synch(gamma_i,zj,z_i)
     Ez_z=ez_lcdm_egmf(zj)
     Bnorm_z=egmf_bnorm_cell_at_z(Bnorm_i,zj,z_i)
     integ=integ+weig(j)*Bnorm_z/((1._prec+zj)*gamma_z*Ez_z)
  end do
  integ=zh*integ
  egmf_phi_between=-real(charge_sign,prec)*e*integ/(m*c*H0)
end function egmf_phi_between

subroutine propagate_no_B_egmf(xvec,z_i,z_f,uvec)
  use constantes, only : prec,c,H0,a0
  implicit none
  real(prec), intent(inout) :: xvec(3),uvec(3)
  real(prec), intent(in) :: z_i,z_f
  real(prec) :: gamma_i,unorm,dir(3),Dr,qgaussDr,integrandDr,scale
  external qgaussDr,integrandDr

  gamma_i=sqrt(1._prec+dot_product(uvec,uvec))
  unorm=sqrt(dot_product(uvec,uvec))
  if (unorm.le.tiny(1._prec)) return
  dir=uvec/unorm
  if (abs(z_i-z_f).lt.1.d-8) then
     Dr=0._prec
  else
     Dr=-c/(a0*H0)*qgaussDr(integrandDr,z_i,z_f,z_i,gamma_i)
  end if
  xvec=xvec+dir*Dr
  scale=(1._prec+z_f)/(1._prec+z_i)
  uvec=uvec*scale
end subroutine propagate_no_B_egmf

subroutine integrate_position_segment(z_i,z_f,gamma_i,upar,uperp,bhat,Bnorm_i,charge_sign,dx)
  use constantes, only : prec,c,H0,a0,ngp,xabsc,weig
  implicit none
  real(prec), intent(in) :: z_i,z_f,gamma_i,upar(3),uperp(3),bhat(3),Bnorm_i
  integer, intent(in) :: charge_sign
  real(prec), intent(out) :: dx(3)
  real(prec) :: zh,zm,zj,scale,gamma_z,Ez_z,phi_z,urot(3),u_z(3)
  real(prec) :: egmf_phi_between,gamma_no_synch,ez_lcdm_egmf
  integer :: j

  dx=0._prec
  zh=0.5_prec*(z_i-z_f)
  zm=0.5_prec*(z_i+z_f)
  do j=1,ngp
     zj=zm+zh*xabsc(j)
     scale=(1._prec+zj)/(1._prec+z_i)
     gamma_z=gamma_no_synch(gamma_i,zj,z_i)
     Ez_z=ez_lcdm_egmf(zj)
     phi_z=egmf_phi_between(z_i,zj,gamma_i,Bnorm_i,charge_sign)
     call rotate_rodrigues(uperp,bhat,phi_z,urot)
     u_z=scale*(upar+urot)
     dx=dx+weig(j)*u_z/(gamma_z*Ez_z)
  end do
  dx=(c/(H0*a0))*zh*dx
end subroutine integrate_position_segment

subroutine propagate_one_B_cell(xvec,z_i,z_f,charge_sign,uvec)
  use constantes, only : prec,B_floor_G
  implicit none
  real(prec), intent(inout) :: xvec(3),uvec(3)
  real(prec), intent(in) :: z_i,z_f
  integer, intent(in) :: charge_sign
  real(prec) :: Bphys(3),Bnorm,bhat(3),gamma_i,scale_f,phi_f
  real(prec) :: upar(3),uperp(3),uperp_rot(3),dx(3)
  real(prec) :: egmf_phi_between

  call EGMF_Bphys(xvec,z_i,Bphys)
  call normalize3(Bphys,bhat,Bnorm)
  if (Bnorm.le.B_floor_G) then
     call propagate_no_B_egmf(xvec,z_i,z_f,uvec)
     return
  end if

  gamma_i=sqrt(1._prec+dot_product(uvec,uvec))
  upar=dot_product(uvec,bhat)*bhat
  uperp=uvec-upar
  call integrate_position_segment(z_i,z_f,gamma_i,upar,uperp,bhat,Bnorm,charge_sign,dx)
  xvec=xvec+dx
  phi_f=egmf_phi_between(z_i,z_f,gamma_i,Bnorm,charge_sign)
  call rotate_rodrigues(uperp,bhat,phi_f,uperp_rot)
  scale_f=(1._prec+z_f)/(1._prec+z_i)
  uvec=scale_f*(upar+uperp_rot)
end subroutine propagate_one_B_cell

subroutine propagate_lepton_egmf(zini,zfinal,eps,x0,y0,zz0,u,v,w,nature)
  use constantes, only : prec,EGMF_phi_max,max_rejection_iter
  implicit none
  real(prec), intent(in) :: zini,zfinal
  integer, intent(in) :: nature
  real(prec), intent(inout) :: eps,x0,y0,zz0,u,v,w
  real(prec) :: xvec(3),dir(3),uvec(3),dirnorm,unorm,gamma_i,zold,znew
  real(prec) :: Bphys(3),Bnorm,bhat(3),total_phi,egmf_phi_between
  integer :: charge_sign,nseg,i

  if (zfinal.gt.zini+tiny(1._prec)) then
     write(*,*), 'propagate_lepton_egmf: zfinal > zini', zini, zfinal
     stop 1
  end if
  if (abs(zini-zfinal).le.tiny(1._prec)) return

  xvec=(/x0,y0,zz0/)
  dir=(/u,v,w/)
  call normalize3(dir,dir,dirnorm)
  if (dirnorm.le.tiny(1._prec)) then
     write(*,*), 'propagate_lepton_egmf: zero direction'
     stop 1
  end if

  gamma_i=max(eps,1._prec)
  unorm=sqrt(max(gamma_i*gamma_i-1._prec,0._prec))
  uvec=unorm*dir
  if (nature.lt.0) then
     charge_sign=-1
  else
     charge_sign=1
  end if

  call EGMF_Bphys(xvec,zini,Bphys)
  call normalize3(Bphys,bhat,Bnorm)
  if (Bnorm.le.tiny(1._prec)) then
     call propagate_no_B_egmf(xvec,zini,zfinal,uvec)
  else
     total_phi=abs(egmf_phi_between(zini,zfinal,gamma_i,Bnorm,charge_sign))
     if (EGMF_phi_max.gt.0._prec) then
        nseg=max(1,ceiling(total_phi/EGMF_phi_max))
     else
        nseg=1
     end if
     if (nseg.gt.max_rejection_iter) then
        write(*,*), 'propagate_lepton_egmf: too many EGMF steps', nseg, total_phi
        stop 1
     end if
     zold=zini
     do i=1,nseg
        znew=zini+(zfinal-zini)*real(i,prec)/real(nseg,prec)
        call propagate_one_B_cell(xvec,zold,znew,charge_sign,uvec)
        zold=znew
     end do
  end if

  eps=sqrt(1._prec+dot_product(uvec,uvec))
  unorm=sqrt(dot_product(uvec,uvec))
  if (unorm.gt.tiny(1._prec)) then
     dir=uvec/unorm
     u=dir(1)
     v=dir(2)
     w=dir(3)
  end if
  x0=xvec(1)
  y0=xvec(2)
  zz0=xvec(3)
end subroutine propagate_lepton_egmf


!------------------------------------------------------------------------------
!Calcul du redshift d'interaction pour la production de paire
! + test pour savoir si le photon d'interaction vient du CMB ou de l'EBL
!------------------------------------------------------------------------------
 subroutine CalculZintPairprod(zlim,zini,zintt)

use constantes
use variables
  implicit none
  real(prec), INTENT(IN) :: zini,zlim
  real(prec), INTENT(OUT) :: zintt
  real(prec)::redzmax,redzmin,a,b,Norma,qgauss,tau,p0,aa,bb,qgaussZ
  real(prec):: PCMB,PEBL,dtaudxPPCMB,dtaudxPPEBL,x,Egammaa,integrandTauPP,rate_total
  real(prec):: integranddtaudxPPCMB,integranddtaudxPPEBL, ran0,zint,comp
  real(prec):: deltaZ,dtaudx,integranddtaudxPP,local_rate
  integer :: iter_bisect
  logical :: use_local_delta

external qgauss,qgaussZ,integrandTauPP, ran0
external integranddtaudxPPCMB,integranddtaudxPPEBL,integranddtaudxPP


Norma=(c/H0)*pi*(r0**2)*(((m*c*c)**3))*((hb*c)**(-3))

!energie du photon gamma donnee par Egamma qui est une variable globale



a=zlim
b=zini


      tau=qgauss(integrandTauPP, a, b)
      tau=tau*Norma

! p0 = fraction de photons gamma qui vont intéragir entre
! leur émission et aujourd'hui

if (tau<1.D-4) then      
p0=tau-(tau**2)/2.+(tau**3)/6.-(tau**4)/24.    
else   
p0=1.-exp(-tau)
end if

x=ran0()

if (x>p0) then ! Si le photon n'interagit pas
  vaInteragir=.false.
  zintt=zlim
else

vaInteragir=.true.

! On utilise la méthode d'inversion pour trouver la prodondeur optique, le redshift et le temps d'intéraction du photon


     redzmax=zini ! valeur max et min de la borne inférieure de l'intégrale
     redzmin=zlim    ! ces valeurs peuvent être ajustées à chaque pas par la dichotomie

     
      comp=log(max(1._prec-x,tiny(1._prec)))


  Egammaa=Egamma
  
  aa=log(1./Egammaa)
  bb=log(max(pairprod_eps_upper_floor,1./Egammaa))

dtaudx=qgaussZ(integranddtaudxPP, aa, bb, zini)

use_local_delta=.false.
local_rate=dtaudx/(Egammaa**2)
if (local_rate.gt.tiny(1._prec)) then
   deltaZ=comp*Norma*((1.+zini)*sqrt((omegaM*((1.+zini)**3)+omegaL)))/local_rate
   use_local_delta=deltaZ.eq.deltaZ.and.abs(deltaZ).lt.1d-5
end if



if (use_local_delta) then

zint=zini+deltaZ

else


     iter_bisect=0
     do while(abs(tau+comp)  > (1.d-8)*abs(comp)) ! Dichotomie
      iter_bisect=iter_bisect+1
      if (iter_bisect.gt.max_rejection_iter) then
         write(*,*), 'CalculZintPairprod: bisection did not converge', zini, zlim, tau, comp
         stop 1
      end if
      a=(redzmin+redzmax)/2.
      tau=qgauss(integrandTauPP, a, b)
      tau=tau*norma


if (redzmax==a.or.redzmin==a) then
tau=-comp
end if

    !write(*,*), tau
      if (tau+comp  < 0.) then
       redzmax=a
      Else if (tau+comp  >0.) then
       redzmin=a
      end IF
           !write(*,*),abs(tau+comp) /abs(comp)




  
     end do
     zint=a
end if

! On regarde si l'intéraction est due au CMB ou à l'EBL.
  
Egammaa=Egamma*(1.+zint)/(1.+zini)

  aa=log(1./Egammaa) 
  bb=log(max(pairprod_eps_upper_floor,1./Egammaa))
  
  if (aa==bb) then

  PEBL=1.
  PCMB=0.

  else
  dtaudxPPCMB=qgaussZ(integranddtaudxPPCMB, aa, bb, zint)
  dtaudxPPEBL=qgaussZ(integranddtaudxPPEBL, aa, bb, zint)

  rate_total=dtaudxPPCMB+dtaudxPPEBL
  if (rate_total.le.0._prec) then
     write(*,*), 'CalculZintPairprod: zero source-selection rate', zint, dtaudxPPCMB, dtaudxPPEBL
     stop 1
  end if
  PCMB=dtaudxPPCMB/rate_total
  PEBL=dtaudxPPEBL/rate_total
  !write(*,*), PCMB, PEBL

  end if

 x=ran0() 
 ! On génère un nombre aléatoire entre 0 et 1 qui va nous servir à savoir si le photon est CMB ou EBL


    if (x < PCMB) then! Si c'est un photon du CMB

    duetoCMB=.true.


    Else! Sinon, c'est un photon de l'EBL, et on tire son énergie par réjection sur    les valeurs tabulées de l'EBL
        ! (subroutine     selecPhotEBL, qui est présente dans mkpairs) 
    duetoCMB=.false.

    end if
zintt=zint

end if

  end subroutine CalculZintPairprod


!------------------------------------------------------------------------------
! Calcul du redshift d'interaction pour diffusion Compton
! + test pour savoir si le photon d'interaction vient du CMB ou de l'EBL
!------------------------------------------------------------------------------

 subroutine CalculZintCompton(zlim,zini,zintt)

use constantes
use variables
  implicit none
  real(prec), INTENT(IN) :: zini,zlim
  real(prec), INTENT(OUT) :: zintt
  real(prec)::redzmax,redzmin,a,b,qgauss,tau,p0,aa,bb
  real(prec):: x,integrandTauCom,deltaZ,dtaudx,local_rate
  real(prec):: ran0, PCMB,PEBL,integranddtaudxComCMB,integranddtaudxComEBL
  real(prec)::dtaudxComCMB,dtaudxComEBL,zint,comp,qgaussZ,integranddtaudxCom
  real(prec):: rate_total
  integer :: iter_bisect
  logical :: use_local_delta
external qgauss,integrandTauCom, ran0,integranddtaudxComCMB,integranddtaudxComEBL
external qgaussZ,integranddtaudxCom


a=zlim
b=zini

!energie de l'electron donnee par Eelec qui est une variable globale

      tau=qgauss(integrandTauCom, a, b)
      tau=tau*c/H0/xi

if (tau<1.D-4) then
p0=tau-(tau**2)/2.+(tau**3)/6.-(tau**4)/24.    
else      
p0=1.-exp(-tau)
end if

x=ran0()


if (x>p0) then ! Si l'electron m'interagit pas

vaInteragir=.false.
zintt=zlim

else

vaInteragir=.true.

!Méthode d'inversion
     
     redzmax=zini ! valeur max et min de la borne inférieure de l'intégrale
     redzmin=zlim    ! ces valeurs peuvent être ajustées à chaque pas par la dichotomie

comp=log(max(1._prec-x,tiny(1._prec)))

  aa=log(compton_eps_min)
  bb=log(compton_eps_max)

dtaudx=qgaussZ(integranddtaudxCom, aa, bb, zini)

use_local_delta=.false.
local_rate=dtaudx
if (local_rate.gt.tiny(1._prec)) then
   deltaZ=comp*(H0/c)*((1.+zini)*sqrt((omegaM*((1.+zini)**3)+omegaL)))/local_rate
   use_local_delta=deltaZ.eq.deltaZ.and.abs(deltaZ).lt.1d-5
end if


if (use_local_delta) then

zint=zini+deltaZ

else


  iter_bisect=0
  DO while(abs(tau+comp) > (1.d-8)*abs(comp)) ! Dichotomie
      iter_bisect=iter_bisect+1
      if (iter_bisect.gt.max_rejection_iter) then
         write(*,*), 'CalculZintCompton: bisection did not converge', zini, zlim, tau, comp
         stop 1
      end if

      a=(redzmin+redzmax)/2.
      tau=qgauss(integrandTauCom, a, b)
      tau=tau*c/H0/xi

if (redzmax==a.or.redzmin==a) then
tau=-comp
end if     

      if (tau+comp<0.) then
       redzmax=a
      Else if (tau+comp>0.) then
       redzmin=a
      end IF


    
     end do

 zint=a

end if

    

! On regarde si l'intéraction est due au CMB ou à l'EBL.
 
  aa=log(compton_eps_min)
  bb=log(compton_eps_max)
  
  dtaudxComCMB=qgaussZ(integranddtaudxComCMB, aa, bb, zint)
  dtaudxComEBL=qgaussZ(integranddtaudxComEBL, aa, bb, zint)

  rate_total=dtaudxComCMB+dtaudxComEBL
  if (rate_total.le.0._prec) then
     write(*,*), 'CalculZintCompton: zero source-selection rate', zint, dtaudxComCMB, dtaudxComEBL
     stop 1
  end if
  PCMB=dtaudxComCMB/rate_total
  PEBL=dtaudxComEBL/rate_total
  

 x=ran0() 
 ! On génère un nombre aléatoire entre 0 et 1 qui va nous servir à savoir si le photon est CMB ou EBL

   if (x < PCMB ) then! Si c'est un photon du CMB

   duetoCMB=.true.
xi=xi1

   Else! Sinon, c'est un photon de l'EBL, et on tire son énergie par réjection sur les valeurs tabulées de l'EBL
   ! (subroutine selecPhotEBL, qui est présente dans isophotcompton) 
   duetoCMB=.false.
xi=xi2
   end if

zintt=zint

end if

 end subroutine CalculZintCompton


!--------------------------------------------------------------------
!      Compton process
!--------------------------------------------------------------------
      subroutine isophotcompton(e1,u1,v1,w1,ep,up,vp,wp,zint)

!    assuming isotropic photon field
!    selects incident angle and energy of photon
!    for compton interaction
!    interaction is then simulated by a call to subroutine compton

! note: all ref change in this routine and its kids have not been rechecked
use constantes, only : DueToCMB, pi, prec, max_rejection_iter
      implicit none
      real(prec) :: e1,u1,v1,w1
      real(prec) :: e2,u2,v2,w2,yu,zint
      real(prec) :: ep,up,vp,wp,ran0
      real(prec) :: csi,mu,smu
      logical rejec
      real(prec) :: phi,cp,sp,cx,sx
      real(prec) :: yt,xt,u3,v3,w3
      real(prec) :: gama,beta,ksi
      real(prec) :: coef,e3
      integer :: iter
      external ran0


  

!  cis angle between the projetion of r in the ex ez plane and the ez vector


      gama=e1+1.
      
      rejec=.true.
       xt=1.
       yt=0. 
       iter=0

! TARGET ENERGY
   


          do while (xt.gt.yt)
             iter=iter+1
             if (iter.gt.max_rejection_iter) then
                write(*,*), 'isophotcompton: target photon rejection did not converge', e1, zint
                stop 1
             end if

if (duetoCMB) then ! si compton est du au CMB


         call selecphot(e2,zint)

!! BB truncated at low energy (to check)

else  ! si le Compton est du à l'EBL
  call selecphotEBL(e2,zint)

end if
             
             yt=yu(e1,e2)
!     compute the angle averaged Compton cross section,
             xt=ran0()
!     used for rejection test
!     write(6,*) e1,e2,yt
          enddo

! TARGET DIRECTION


      call genmu(e1,e2,mu)
!     write(6,*) mu 
! select angle between electron and photon (isotropic photons)
      
      phi=2.*pi*ran0()
      cp=cos(phi)
      sp=sin(phi)
      mu=max(-1._prec,min(1._prec,mu))
      smu=sqrt(max(0._prec,1._prec-mu**2))
      csi=atan2(u1,w1)
      cx=cos(csi)
      sx=sin(csi)      
!   determine incident photon direction in global frame:  
      u2=smu*(cp*cx+sp*sx*v1)+mu*u1
      v2=-smu*sp*(w1*cx+u1*sx)+mu*v1
      w2=smu*(-cp*sx+sp*cx*v1)+mu*w1

      beta=sqrt(e1*(e1+2.))/gama
      coef=1.-mu*beta
      ksi=2.*e2*gama*coef
      e3=e1
      ep=e2
      up=u2
      vp=v2
      wp=w2
      u3=u1
      v3=v1
      w3=w1

!      write(6,*) up,vp,wp,ep,e3,ksi,u3,v3,w3
      call compton(up,vp,wp,ep,e3,ksi,u3,v3,w3)
!      write(6,*) up,vp,wp,ep,e3,ksi,u3,v3,w3

      call renorme(up,vp,wp) 
      call renorme(u3,v3,w3) 
      e1=e3
      u1=u3
      v1=v3
      w1=w3
	
      end subroutine isophotcompton


      function yu(e1,e)
            use constantes, only : prec
      implicit none
!   angle averaged  Compton cross-section for lepton of energy e1
!   and photon of energy e2 
!   (in units of sigma_T)
      
      real(prec) :: yu,g,e,e1,b,phix
      real(prec) :: xx,xxm,xxp,umb,xst
      g=e1+1.
      b=sqrt(e1*(e1+2.))/g
      IF (g.gt.1d2) THEN
         umb=1./2./g**2
      ELSE
         umb=1.-b
      ENDIF
      xx=2.*e*g
      xxp=xx*(1.+b)
      xxm=xx*umb
      xst=(phix(xxp)-phix(xxm))/xx**2.
      xst=xst*3./(8*b)
      yu=xst
      end

      function phix(x)
            use constantes, only : prec
      implicit none
! phix=\int_0^x (x*sigma(x))dx   (PSS83 p 319)
      real(prec) :: x,phix
      IF (x.lt.0.5) THEN 
         phix=x*x/6.+0.047*x*x*x-0.03*x**4.+0.5*x*x/(1.+x)
      ELSE 
         IF (x.lt.3.5) THEN 
            phix=(1.+x)*log(1.+x)-0.94*x-0.00925
         ELSE 
            phix=(1.+x)*log(1.+x)-0.5*x
       phix=phix-13.16*log(2.+0.076*x)+9.214
         ENDIF
      ENDIF
      END

      subroutine genmu(ec,e,mu)
! For isotropic monoenergetic photon gas,
!  generates mu=cos(tetha) tetha= angle between incident electron and photon. 
      use constantes, only : prec, max_rejection_iter
      IMPLICIT NONE

      real(prec) :: gama,e,mu,xt,y,fx,xsx
      real(prec) :: xmin,xmax,f0,lnf0
      real(prec) :: beta,gfx,fmin,fmax,a1,ran0
      real(prec) :: x0,gfdex,a,b,lnfx,ec
      integer :: iter, iter_solve

      gama=ec+1.
      beta=sqrt(ec*(ec+2.))/gama

      if (1.-beta.gt.1d-5) THEN
      xmin=2.*gama*e*(1.-beta)
      ELSE 
      xmin=e/gama
      ENDIF
      xmax=2.*gama*e*(1.+beta)
     

      IF (xmax.lt.0.1) then
!  KN effects are weak: use simple rejection technique
        y=0.
        xt=1.
        iter=0
        do while (xt.gt.y) 
           iter=iter+1
           if (iter.gt.max_rejection_iter) then
              write(*,*), 'genmu: Thomson rejection did not converge', ec, e
              stop 1
           end if
           a1=ran0()
           mu=(1.-sqrt((1.+beta)**2-4.*beta*a1))/beta
           IF (abs(mu).gt.1.) THEN
              write(6,*) 'error mu',a1,beta,mu
              mu=mu/abs(mu)
              
           endif
           x0=2*E*gama*(1.-mu*beta)
           y=0.75*xsx(x0)/x0
           xt=ran0()
        enddo
      ELSE
! KN effects are strong
! numerical inversion of an aproximation to the full distribution
! then rejection.

      fmin=gfx(xmin)
      fmax=gfx(xmax)

      y=0.
      xt=1.
      iter=0
      do while (xt.gt.y) 
         iter=iter+1
         if (iter.gt.max_rejection_iter) then
            write(*,*), 'genmu: KN rejection did not converge', ec, e
            stop 1
         end if
         a1=ran0()
         F0=a1*(fmax-fmin)+fmin
         lnf0=log(f0)        
         x0=2.*e*gama         
         gfdex=gfx(x0)        

!      solving gfx(x)=f0 using using iterative method
         iter_solve=0
         do while (abs(gfdex/f0-1.).gt.1d-8) 
            iter_solve=iter_solve+1
            if (iter_solve.gt.max_rejection_iter) then
               write(*,*), 'genmu: inverse solve did not converge', ec, e, x0
               stop 1
            end if
            lnfx=log(gfdex)
            a=x0*fx(x0)/gfdex
            b=lnfx-lnf0-a*log(x0)
            
            x0=exp(-b/a)
            gfdex=gfx(x0)
         enddo
         y=xsx(x0)/fx(x0)
         xt=ran0()
      enddo
      mu=(1.-x0/2./gama/e)/beta
      endif
      end

      function xsx(x)
      use constantes, only : prec
      implicit none
! x*sigma(x)  see PSS83, p319
      real(prec) :: x,xsx
      IF (x.gt.0.5) THEN
       xsx=(1.-4./x-8./x/x)*log(1.+x)+0.5
       xsx=xsx+8./x-1./2./(1.+x)**2.
      ELSE
        xsx=1./3.+0.141*x-0.12*x*x+(1.+0.5*x)/(1.+x)**2
        xsx=xsx*x
      ENDIF
      END
        
      function gfx(x)
      use constantes, only : prec
      implicit none
!   primitive of fx see below
      real(prec) :: gfx,x,u
      u=1.+x
      gfx=u*log(u)+0.5*(exp(-x)-x-1.)
      end

      function fx(x)
      use constantes, only : prec
      implicit none
! 0.7<xsx/fx<1.     fx-> xsx when x-> \infty  
! fx is used to model the Compton incident angle by rejection tecnique
      real(prec) :: fx,x
      fx=log(1.+x)+0.5*(1.-exp(-x))
      end
 
  
!*******************************************************************
      subroutine compton(u,v,w,e,ec,xi,dex,dey,dez)
!*******************************************************************
      use constantes, only : m,c,pi, prec, max_rejection_iter

IMPLICIT NONE
      real(prec) :: u,v,w,e,ran0
      real(prec) :: beta,gama,dex,dey,dez
      real(prec) :: ud,vd,wd,a1,a2,mud,q,phi
      real(prec) ::  ro,y,xi,de,eps,xdsxi,vv
      real(prec) :: gama2,e2
      real(prec) :: mu0,vv2,fact, dex2,dey2,dez2
      real(prec) :: csphi,snphi,smud,t,csphismud,snphismud
      real(prec) :: e1x,e1y,e1z,e2x,e2y,e2z,dnorm
      real(prec) :: ec
      integer :: iter

      
!     common /mc2/mc2 
      gama=ec+1.
      beta=sqrt(ec*(ec+2.))/gama

!     direction du photon diffuse (par test de rejection)
      a1=1.
! le bug etait la :
      y=0.
xdsxi=1._prec
! la ligne precedente avait ete supprimmee
      iter=0
      do while (2*a1.ge.y)
         iter=iter+1
         if (iter.gt.max_rejection_iter) then
            write(*,*), 'compton: rejection loop did not converge', ec, e, xi
            stop 1
         end if
         
         a1=ran0()
         a2=ran0()
         phi=2.*pi*a2
         
         mu0=2.*a1-1.
         mud=max(-1._prec,min((beta+mu0)/(1+beta*mu0),1._prec))
!       min( added on 17/4/09 to avoid apparition of  NaN in some rare cases when comuting smud
         smud=sqrt(max(0._prec,1._prec-mud**2))
         
         csphi=cos(phi)
         snphi=sin(phi)
         csphismud=csphi*smud
         snphismud=snphi*smud
         dnorm=sqrt(dex**2+dey**2+dez**2)
         if (dnorm.le.tiny(1._prec)) then
            dex=0._prec
            dey=0._prec
            dez=1._prec
         else
            dex=dex/dnorm
            dey=dey/dnorm
            dez=dez/dnorm
         end if
         ro=sqrt(dex**2+dey**2)
         if (ro.le.tiny(1._prec)) then
            e1x=1._prec
            e1y=0._prec
            e1z=0._prec
            e2x=0._prec
            e2y=dez
            e2z=0._prec
         else
            e1x=dey/ro
            e1y=-dex/ro
            e1z=0._prec
            e2x=dex*dez/ro
            e2y=dey*dez/ro
            e2z=-ro
         end if
         
         ud=mud*dex+csphismud*e1x+snphismud*e2x
         vd=mud*dey+csphismud*e1y+snphismud*e2y
         wd=mud*dez+csphismud*e1z+snphismud*e2z
         
         q=u*ud+v*vd+w*wd
         t=gama*(1.-mud*beta)
         
         if (t.le.tiny(1._prec)) cycle
         eps=e*(1.-q)/(t)
         xdsxi=1./(1.+eps)
         
         
         a1=ran0()
         
         y=4.*((eps/xi)**2-eps/xi)*xdsxi**2+xdsxi+xdsxi**3
         
      enddo
!      write(6,*) 'sc:',smud,mud,mu0,beta,ro,y
!     energie du photon diffuse
      
      e2=xi*xdsxi/(2.0*t)
      
      de=e-e2
      gama2=de+gama

vv=c*sqrt(max(0._prec,1._prec-gama**(-2)))
vv2=c*sqrt(max(0._prec,1._prec-gama2**(-2)))
if (vv2.le.tiny(1._prec)) then
   write(*,*), 'compton: final lepton velocity too small', gama2
   stop 1
end if
fact=1./(gama2*m*vv2)
dex2=fact*(m*c*c*e/c*u+gama*m*vv*dex-m*c*c*e2/c*ud)
dey2=fact*(m*c*c*e/c*v+gama*m*vv*dey-m*c*c*e2/c*vd)
dez2=fact*(m*c*c*e/c*w+gama*m*vv*dez-m*c*c*e2/c*wd)


      gama=gama2
      ec=ec+de
      u=ud
      v=vd
      w=wd
      e=e2
 dex=dex2
 dey=dey2
 dez=dez2
      end

!*****************************************************************
      subroutine renorme(u,v,w)
!*****************************************************************
      use constantes, only : prec
      IMPLICIT NONE

      real(prec) :: u,v,w,norm
      norm=sqrt(u**2+v**2+w**2)
      if (norm.le.tiny(1._prec)) then
         write(*,*), 'renorme: zero vector'
         stop 1
      end if
      u=u/norm
      v=v/norm
      w=w/norm
      end







!--------------------------------------------------------------------
! Trouve le redshift, position et direction
! correspondants au moment ou une particule
! qui n'interagit pas passe la limite de detection.
! Utile pour calculer la profondeur optique (borne inf)
! et les proprietes au moment de la detection
!--------------------------------------------------------------------
! Pour photon
!--------------------------------------------------------------------
 subroutine TrouveZlimPhot(z0,zlim,xx,yy,zz,u,v,w,eps,l)
 use constantes, only : prec,max_rejection_iter
  implicit none
external distancePhoton
real(prec), intent(IN):: l,u,v,w,eps,z0
real(prec), intent(INOUT):: xx,yy,zz
real(prec), intent(OUT)::zlim
real(prec):: dist,x0,y0,zz0,eps0,a,epss,redzmax,redzmin
integer :: iter_bisect

redzmin=-1.
redzmax=z0
a=z0

x0=xx
y0=yy
zz0=zz
eps0=eps

 dist=sqrt(xx**2+yy**2+zz**2)
iter_bisect=0
    
do while(abs(dist-l)/l  > (1d-8)) ! Dichotomie
iter_bisect=iter_bisect+1
if (iter_bisect.gt.max_rejection_iter) then
   write(*,*), 'TrouveZlimPhot: bisection did not converge', z0, l, dist
   stop 1
end if


 a=(redzmin+redzmax)/2.

if (redzmax==a.or.redzmin==a) then
dist=l
else

xx=x0
yy=y0
zz=zz0
epss=eps0



 call distancePhoton(z0,a,epss,xx,yy,zz,u,v,w) 
 
 dist=sqrt(xx**2+yy**2+zz**2)




 if (dist<l) then
  redzmax=a
 Else
  redzmin=a
 end if

end if


end do

zlim=a
xx=x0
yy=y0
zz=zz0


 end subroutine TrouveZlimPhot

!--------------------------------------------------------------------
! Pour electron
!--------------------------------------------------------------------
 subroutine TrouveZlimLep(z0,zlim,xx,yy,zz,u,v,w,eps,l,nature)
 use constantes, only : prec,max_rejection_iter
  implicit none
external distancePhoton
real(prec), intent(IN):: l,u,v,w,eps
real(prec), intent(INOUT):: z0,xx,yy,zz
real(prec), intent(OUT)::zlim
real(prec):: dist,x0,y0,zz0,eps0,a,epss,redzmax,redzmin,uu,vv,ww
integer, intent(IN):: nature
integer :: iter_bisect

redzmin=-1.
redzmax=z0
a=z0

dist=1.

x0=xx
y0=yy
zz0=zz
eps0=eps
 dist=sqrt(xx**2+yy**2+zz**2)
iter_bisect=0
    
do while(abs(dist-l)/l  > (1d-8)) ! Dichotomie
  iter_bisect=iter_bisect+1
  if (iter_bisect.gt.max_rejection_iter) then
   write(*,*), 'TrouveZlimLep: bisection did not converge', z0, l, dist
   stop 1
  end if

  a=(redzmin+redzmax)/2.

if (redzmax==a.or.redzmin==a) then

dist=l

else

  xx=x0
  yy=y0
  zz=zz0
  epss=eps0
  uu=u
  vv=v
  ww=w

  call trajectoireLepton(z0,a,epss,xx,yy,zz,uu,vv,ww,nature) 
 
  dist=sqrt(xx**2+yy**2+zz**2)

   if (redzmax==a.or.redzmin==a) then
   dist=l
   end if

  if (dist<l) then
  redzmax=a
  Else
  redzmin=a
  end if
end if

end do

zlim=a
xx=x0
yy=y0
zz=zz0


 end subroutine TrouveZlimLep

!=============================================================================!
!=============================================================================!
!        get a particle from stack                                            !
!=============================================================================!
subroutine get_particle(nature,redshift,energie,xx,yy,zz,u,v,w,poids)
 use constantes, only : par, prec, TaillePile
  implicit none

  real (prec) :: redshift,energie,xx,yy,zz,u,v,w,poids
  integer :: nature

if (TaillePile.le.0) then
   write(*,*), 'get_particle: empty particle stack'
   stop 1
end if

nature=par(TaillePile)%nature
redshift=par(TaillePile)%redshift
energie=par(TaillePile)%ener
xx=par(TaillePile)%x
yy=par(TaillePile)%y
zz=par(TaillePile)%z
u=par(TaillePile)%u
v=par(TaillePile)%v
w=par(TaillePile)%w
poids=par(TaillePile)%poids

  TaillePile=TaillePile-1

end subroutine get_particle

!=============================================================================!
!=============================================================================!
!        add a particle to stack                                              !
!=============================================================================!
subroutine store_particle(nature,redshift,energie,xx,yy,zz,u,v,w,poids)

  use constantes
  implicit none

  real(prec) :: energie,xx,yy,zz,u,v,w,poids,redshift,ran0
  integer :: nature
  integer :: i,n
external ran0

                  ! sampling weight for produced particle
  if (ran0().gt.frac) return      ! disregard particle with prob. (1-aweight)

  if (TaillePile.ge.size(Par)) then
     write(*,*), 'store_particle: particle stack overflow', TaillePile, size(Par), nature, redshift, energie
     stop 1
  end if

  TaillePile=TaillePile+1                         ! enlarge stack


  act = particule(nature,redshift,energie,xx,yy,zz,u,v,w,poids)

  if (TaillePile.gt.1) then                 ! add particle to E-ordered stack
     do i=1,TaillePile-1
        n=TaillePile-i
        if(par(n)%ener.gt.energie)then
           par(n+1)=act                     ! add particle to stack
par(n+1)%poids=par(n+1)%poids/frac
           return
        else
           par(n+1)=par(n)                ! re-arrange stack
        endif
     enddo
  endif
  par(1)=act                        ! 1st particle in stack
par(1)%poids=par(1)%poids/frac

end subroutine store_particle

!=============================================================================!
!=============================================================================!
subroutine register(e0,weight,nature)
  use constantes
  implicit none
  integer nature,left, right
  real(prec) ::  e0,weight,energy_ev
  external r8vec_bracket


! diffuse energy spectrum:
  energy_ev=e0*511000._prec
  if (energy_ev.lt.grille(1)) then
     spec_underflow_count=spec_underflow_count+1
     return
  else if (energy_ev.gt.grille(n_bin)) then
     spec_overflow_count=spec_overflow_count+1
     return
  end if
  call r8vec_bracket ( n_bin, grille, energy_ev, left, right )
  spec(left,abs(nature))=spec(left,abs(nature))+weight*e0
end subroutine register

!=============================================================================!
!=============================================================================!
subroutine user_output(n_max) 
  use constantes
  implicit none
  integer n_max,i
  real(prec) :: total_spec
  
  if (n_max.gt.0) then
     spec = spec/real(n_max,prec)
  end if
  total_spec=sum(spec(:,:))



  open(unit=31,file='spec_diff') ! energy spectrum

  do i=1,n_bin-1
     if (total_spec.gt.0._prec) then
        write(31,*) grille(i),(spec(i,0)+spec(i,1))/total_spec,&
                0.00003*grille(i)**0.5
     else
        write(31,*) grille(i),0._prec,0.00003*grille(i)**0.5
     end if
  end do

  close(31)

  write(10,*), 'Spectrum underflow skipped = ', spec_underflow_count
  write(10,*), 'Spectrum overflow skipped = ', spec_overflow_count

end subroutine user_output
